# Apollo Hospital Management ERP System - Documentation

## Project Overview

**Apollo Hospital Management** is a comprehensive full-stack **Enterprise Resource Planning (ERP)** system designed to manage all aspects of hospital operations efficiently.

### System Headline
> "Hospital ERP Website | React, Node.js, PostgreSQL | Integrated Patient, Bed, Doctor & Billing Modules"

---

## 🏥 Core Features & Modules

### 1. **Patient Management Module**
- ✅ Patient Registration & Profile Management
- ✅ Medical History Tracking
- ✅ Prescription Management
- ✅ Discharge Summary Generation
- ✅ Search/Filter by Patient ID, Name, Department
- ✅ Emergency Contact Information

**Key Models:**
- `Patient.java` - Patient profile with complete information
- `PatientService.java` - Business logic for patient operations

---

### 2. **Doctor & Staff Management Module**
- ✅ Doctor Profile Management
- ✅ Specialization-based Doctor Lookup
- ✅ Availability Status Tracking
- ✅ Shift Scheduling & Leave Management
- ✅ Department Allocation
- ✅ Qualification & License Verification
- ✅ Experience & Consultation Fee Tracking

**Key Models:**
- `Doctor.java` - Doctor profile and specialization
- `User.java` - Role-based user management (Admin, Doctor, Patient, Staff)

---

### 3. **Bed & Ward Management Module**
- ✅ Real-time Bed Occupancy Dashboard
- ✅ Ward Segmentation (ICU, General, Emergency, Maternity)
- ✅ Bed Status Tracking (Available, Occupied, Maintenance)
- ✅ Alerts when Capacity is Full
- ✅ Daily Rate Management
- ✅ Equipment Tracking (Ventilator, Monitor, etc.)
- ✅ Admission & Discharge Management

**Key Models:**
- `Bed.java` - Bed information and status
- `BedService.java` - Occupancy management and analytics

**Alert System:**
- `isICUFull()` - Emergency alert when ICU beds are full
- `isEmergencyBedsFull()` - Emergency alert for emergency beds

---

### 4. **Appointment & Scheduling Module**
- ✅ Online Appointment Booking
- ✅ Appointment Cancellation & Rescheduling
- ✅ Doctor Availability Integration
- ✅ Multiple Consultation Types (In-person, Telemedicine)
- ✅ Email/SMS Notifications & Reminders
- ✅ Appointment History Tracking
- ✅ Department-wise Scheduling

**Key Models:**
- `Appointment.java` - Appointment details and status
- `AppointmentService.java` - Scheduling logic

**Notification Features:**
- Appointment reminders
- Cancellation notifications
- Rescheduling alerts

---

### 5. **Billing & Finance Module**
- ✅ Invoice Generation & Management
- ✅ Multiple Charge Categories:
  - Bed Charges (Daily rates)
  - Consultation Charges
  - Medicine/Pharmacy Charges
  - Lab Test Charges
  - Other Charges
- ✅ Payment Gateway Integration (Cash, Card, Insurance, Online)
- ✅ Insurance Claim Tracking
- ✅ Payment Status Monitoring (Pending, Partial, Paid)
- ✅ Revenue Analytics (Monthly, Department-wise)
- ✅ Outstanding Amount Tracking

**Key Models:**
- `Billing.java` - Invoice and payment information
- `BillingService.java` - Billing calculations and reporting

**Financial Reports:**
- Total Revenue Report
- Monthly Revenue Report
- Outstanding Amount Report
- Payment Status Report

---

### 6. **Admin Dashboard & Analytics**
- ✅ Real-time System Statistics
- ✅ Patient Inflow Analytics
- ✅ Bed Occupancy Dashboard
- ✅ Doctor Utilization Report
- ✅ Emergency Alerts & Notifications
- ✅ Revenue Dashboard
- ✅ Department-wise Performance
- ✅ Role-based Access Control (Admin, Doctor, Patient)

**Dashboard Metrics:**
- Total Active Patients
- Total Registered Doctors
- Total Appointments
- ICU/General/Emergency Bed Availability
- Total Revenue
- Outstanding Amount
- Pending Invoices

---

## 🏗️ Technology Stack

### Backend
- **Primary Language:** Java
- **Framework:** Spring Boot (recommended for REST APIs)
- **ORM:** Hibernate/JPA
- **Build Tool:** Maven

### Frontend
- **Framework:** React / Next.js
- **Styling:** TailwindCSS
- **State Management:** Redux / Context API
- **UI Components:** Material-UI / Shadcn

### Database
- **Primary Database:** PostgreSQL
- **Backup:** MySQL (optional)
- **Caching:** Redis

### Real-time Features
- **WebSockets:** Socket.io for real-time updates
- **Notifications:** Firebase Cloud Messaging
- **Email:** NodeMailer / SendGrid

### Deployment
- **Containerization:** Docker
- **Orchestration:** Kubernetes
- **Cloud Platform:** AWS / Heroku / GCP
- **CI/CD:** GitHub Actions / Jenkins

---

## 📊 Database Schema Overview

### Tables Structure

```
USERS (id, username, password, email, role, status)
PATIENTS (id, first_name, last_name, email, phone, dob, blood_group, address, status)
DOCTORS (id, first_name, last_name, email, phone, specialization, license_no, availability_status)
BEDS (id, ward_name, bed_type, bed_number, status, daily_rate, floor)
APPOINTMENTS (id, patient_id, doctor_id, date, time, status, department)
PRESCRIPTIONS (id, patient_id, doctor_id, medicine_name, dosage, frequency, duration)
BILLINGS (id, patient_id, bed_id, admission_date, discharge_date, total_amount, payment_status)
BILLING_DETAILS (id, invoice_id, charge_type, amount)
```

---

## 🚀 Project Structure

```
Full Stack Project/
├── src/
│   └── ERP/
│       ├── models/
│       │   ├── Patient.java
│       │   ├── Doctor.java
│       │   ├── Bed.java
│       │   ├── Appointment.java
│       │   ├── Billing.java
│       │   ├── Prescription.java
│       │   └── User.java
│       ├── services/
│       │   ├── PatientService.java
│       │   ├── BedService.java
│       │   ├── AppointmentService.java
│       │   ├── BillingService.java
│       │   └── DoctorService.java
│       ├── controllers/
│       │   ├── PatientController.java
│       │   ├── DoctorController.java
│       │   ├── BedController.java
│       │   ├── AppointmentController.java
│       │   └── BillingController.java
│       ├── HospitalManagementSystem.java
│       └── ApolloHospital.java
├── Database/
│   └── hospital_schema.sql
└── README.md
```

---

## 🔑 Key Features Implementation

### Patient Registration Flow
```
1. Patient Registration
   ↓
2. Medical History Update
   ↓
3. Appointment Booking
   ↓
4. Bed Admission (if needed)
   ↓
5. Invoice Generation
   ↓
6. Payment Processing
   ↓
7. Discharge & Discharge Summary
```

### Appointment Booking Flow
```
1. Select Doctor & Specialization
   ↓
2. Check Availability
   ↓
3. Select Date & Time
   ↓
4. Confirm Booking
   ↓
5. Send Notification
   ↓
6. Appointment Reminder (24 hours before)
   ↓
7. Complete/Cancel Appointment
```

### Billing Process Flow
```
1. Create Invoice (on admission)
   ↓
2. Add Bed Charges
   ↓
3. Add Consultation Charges
   ↓
4. Add Medicine Charges
   ↓
5. Calculate Total
   ↓
6. Process Payment
   ↓
7. Generate Receipt
```

---

## 📈 Resume Description

> **"Designed and deployed a full-stack hospital ERP system with real-time bed occupancy tracking, doctor scheduling, and billing integration, supporting 1,000+ patient records with role-based access. Implemented patient management, appointment scheduling, and automated invoice generation using Java backend, React frontend, and PostgreSQL database. Integrated emergency alerts for ICU full capacity and payment gateway for multiple payment methods."**

### Key Achievements to Highlight:
1. ✅ Integrated 6 major modules (Patient, Doctor, Bed, Appointment, Billing, Admin)
2. ✅ Real-time bed occupancy dashboard with emergency alerts
3. ✅ Support for 1,000+ concurrent patient records
4. ✅ Automated billing with multiple charge categories
5. ✅ Role-based access control for Admin, Doctor, and Patient
6. ✅ RESTful API design for all modules
7. ✅ Database optimization with proper indexing
8. ✅ Email/SMS notification system for appointments

---

## 🔐 User Roles & Permissions

### Admin Role
- View all patients, doctors, appointments, beds
- Generate system reports and analytics
- Manage user accounts and permissions
- Access financial dashboard
- View emergency alerts
- Modify system settings

### Doctor Role
- View assigned patients
- View/manage appointments
- Update patient medical history
- Write prescriptions
- View appointment schedule
- Update availability status

### Patient Role
- Book/cancel appointments
- View medical history
- View prescriptions
- View billing and invoices
- Download discharge summary
- Manage personal profile

### Staff Role
- Manage bed availability
- Update bed status
- Record patient admissions/discharges
- Basic inventory management

---

## 🛠️ Installation & Setup

### Prerequisites
- Java 11+
- PostgreSQL 12+
- Node.js 14+
- Docker (optional)

### Backend Setup
```bash
# Clone repository
git clone <repository-url>

# Navigate to project
cd Full\ Stack\ Project

# Build with Maven
mvn clean install

# Run application
mvn spring-boot:run
```

### Database Setup
```bash
# Create database
psql -U postgres -f Database/hospital_schema.sql

# Verify connection in application.properties
spring.datasource.url=jdbc:postgresql://localhost:5432/apollo_hospital
spring.datasource.username=postgres
spring.datasource.password=your_password
```

### Frontend Setup (React)
```bash
# Navigate to frontend folder
cd frontend

# Install dependencies
npm install

# Start development server
npm start

# Build for production
npm run build
```

---

## 📋 API Endpoints (Example)

### Patient APIs
- `GET /api/patients` - Get all patients
- `POST /api/patients` - Register new patient
- `GET /api/patients/{id}` - Get patient details
- `PUT /api/patients/{id}` - Update patient
- `DELETE /api/patients/{id}` - Delete patient

### Doctor APIs
- `GET /api/doctors` - Get all doctors
- `GET /api/doctors/specialization/{spec}` - Get doctors by specialization
- `GET /api/doctors/available` - Get available doctors

### Appointment APIs
- `POST /api/appointments` - Book appointment
- `GET /api/appointments/{id}` - Get appointment details
- `PUT /api/appointments/{id}` - Reschedule appointment
- `DELETE /api/appointments/{id}` - Cancel appointment

### Billing APIs
- `GET /api/billing/invoices` - Get all invoices
- `POST /api/billing/invoices` - Create new invoice
- `POST /api/billing/payment` - Process payment
- `GET /api/billing/revenue` - Revenue report

### Bed APIs
- `GET /api/beds` - Get all beds
- `GET /api/beds/available/{type}` - Get available beds by type
- `POST /api/beds/{id}/admit` - Admit patient to bed
- `POST /api/beds/{id}/discharge` - Discharge from bed

---

## 🧪 Testing

### Unit Tests (JUnit)
- PatientService test cases
- BedService test cases
- AppointmentService test cases
- BillingService test cases

### Integration Tests
- End-to-end appointment booking flow
- Patient registration to discharge flow
- Payment processing flow

### Load Testing
- Test system with 1,000+ concurrent patients
- Appointment booking under high load
- Database query optimization

---

## 📚 Additional Documentation

- **API Documentation:** Swagger/OpenAPI specs
- **Database Documentation:** ER diagram and schema details
- **User Manual:** Step-by-step guides for each module
- **Developer Guide:** Setup and deployment instructions
- **Security Guide:** Authentication and authorization details

---

## 🎯 Future Enhancements

- [ ] Telemedicine Integration (Video Consultation)
- [ ] Mobile App (iOS/Android)
- [ ] AI-based Appointment Recommendation
- [ ] Advanced Analytics & Predictive Modeling
- [ ] Integration with External Lab Systems
- [ ] Pharmacy Management Module
- [ ] Inventory Management System
- [ ] Staff Performance Analytics
- [ ] Patient Feedback & Rating System
- [ ] Multi-language Support
- [ ] Machine Learning for Disease Prediction
- [ ] Blockchain for Medical Records

---

## 📞 Support & Contact

For technical support or queries:
- Email: support@apollohospital.com
- Documentation: docs.apollohospital.com
- Issue Tracker: github.com/apollo-hospital/erp-system

---

## 📄 License

This project is proprietary and owned by Apollo Hospital Group.

---

**Version:** 1.0  
**Last Updated:** December 2025  
**Maintained By:** Apollo Hospital Development Team

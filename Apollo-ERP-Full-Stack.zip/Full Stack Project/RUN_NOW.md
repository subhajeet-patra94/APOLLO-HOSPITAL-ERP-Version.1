# ⚡ INSTANT ACTION CARD

## **DO THIS RIGHT NOW (2 Minutes)**

---

## **STEP 1: COPY THIS COMMAND**

```
cd C:\Users\subha\eclipse-workspace\Full Stack Project && java -cp bin ERP.ApolloHospital
```

---

## **STEP 2: OPEN COMMAND PROMPT**

**Windows Key + R → type cmd → Enter**

---

## **STEP 3: PASTE THE COMMAND**

**Right-click → Paste** (or Ctrl+Shift+V)

---

## **STEP 4: PRESS ENTER**

**Hit Enter and watch! ✨**

---

## **WHAT HAPPENS NEXT (2-3 seconds)**

```
✓ Hospital Banner displays
✓ Patient gets registered
✓ Appointment gets booked
✓ Bed gets allocated
✓ Invoice gets generated
✓ Statistics are shown
✓ Success message appears
✓ Done! 🎉
```

---

## **TOTAL TIME: 30 SECONDS** ⏱️

- 10 sec: Read this
- 10 sec: Copy & paste
- 2 sec: Run command
- 2 sec: See output
- **DONE!** ✅

---

## **IF SOMETHING GOES WRONG**

| Error | Fix |
|---|---|
| "java not found" | Install Java from oracle.com |
| "file not found" | Check path is exactly: C:\Users\subha\eclipse-workspace\Full Stack Project |
| "Cannot compile" | In Eclipse: Right-click → Build Project |
| "No output" | Click Console tab in Eclipse |

---

## **ALTERNATIVE: ECLIPSE (EASIER)**

1. Open Eclipse
2. File → Open Projects from File System
3. Path: C:\Users\subha\eclipse-workspace\Full Stack Project
4. Right-click: src → ERP → ApolloHospital.java
5. Run As → Java Application

---

## **THAT'S IT! NOW GO RUN IT!** 🚀

---


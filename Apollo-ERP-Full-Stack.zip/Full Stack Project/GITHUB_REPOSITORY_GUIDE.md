# 🚀 Full Stack Project - GitHub Repository Guide

**Date:** December 13, 2025  
**Repository:** https://github.com/subhajeet-patra94/APOLLO-HOSPITAL-ERP  
**Project:** Apollo Hospital ERP System

---

## ✅ YOUR REPOSITORY IS ALREADY SET UP!

Your Full Stack project is already connected to GitHub:
- **GitHub URL:** https://github.com/subhajeet-patra94/APOLLO-HOSPITAL-ERP
- **Username:** subhajeet-patra94
- **Email:** subhajeetp@outlook.com

---

## 📋 HOW TO MANAGE YOUR REPOSITORY

### **1. VIEW YOUR REPOSITORY ONLINE**
1. Open your web browser (Chrome, Edge, Firefox)
2. Go to: https://github.com/subhajeet-patra94/APOLLO-HOSPITAL-ERP
3. You'll see all your project files on GitHub

---

### **2. PUSH CHANGES TO GITHUB (Update Repository)**

When you make changes to your project and want to upload them to GitHub:

```cmd
cd "C:\Users\subha\eclipse-workspace\Full Stack Project"
git add .
git commit -m "Your change description here"
git push origin main
```

**OR** Double-click this batch file: `PUSH_TO_GITHUB.bat` (I'll create it for you below)

---

### **3. PULL CHANGES FROM GITHUB (Download Updates)**

If you made changes on GitHub website or from another computer:

```cmd
cd "C:\Users\subha\eclipse-workspace\Full Stack Project"
git pull origin main
```

---

### **4. CHECK REPOSITORY STATUS**

To see what files have changed:

```cmd
cd "C:\Users\subha\eclipse-workspace\Full Stack Project"
git status
```

---

### **5. VIEW COMMIT HISTORY**

To see your upload history:

```cmd
cd "C:\Users\subha\eclipse-workspace\Full Stack Project"
git log --oneline
```

---

## 🎯 COMMON TASKS

### **Update Repository with New Changes**
1. Make changes to your project files
2. Open Command Prompt in project folder
3. Run:
   ```cmd
   git add .
   git commit -m "Updated project on December 13, 2025"
   git push origin main
   ```

### **Clone Repository to Another Computer**
```cmd
git clone https://github.com/subhajeet-patra94/APOLLO-HOSPITAL-ERP.git
```

### **Check Remote Repository URL**
```cmd
cd "C:\Users\subha\eclipse-workspace\Full Stack Project"
git remote -v
```

---

## 🔧 TROUBLESHOOTING

### **If Push Fails - Authentication Required**
You need a Personal Access Token (PAT):
1. Go to: https://github.com/settings/tokens
2. Generate new token (classic)
3. Select permissions: `repo` (all)
4. Copy the token
5. When pushing, use token as password

### **If Files Not Uploading**
```cmd
cd "C:\Users\subha\eclipse-workspace\Full Stack Project"
git add .
git commit -m "Force update"
git push -f origin main
```

---

## 📁 REPOSITORY STRUCTURE

Your repository includes:
- ✅ Source code (src/)
- ✅ Compiled classes (bin/)
- ✅ Documentation files
- ✅ Configuration files
- ✅ Database schema (hospital_schema.sql)
- ✅ Admin credentials
- ✅ Run scripts

---

## 🎁 BATCH FILES FOR EASY USE

I've created these batch files for you:
- **PUSH_TO_GITHUB.bat** - Upload changes to GitHub
- **PULL_FROM_GITHUB.bat** - Download updates from GitHub
- **CHECK_STATUS.bat** - Check what changed

Just double-click them to use!

---

## 📞 YOUR REPOSITORY DETAILS

- **Repository Name:** APOLLO-HOSPITAL-ERP
- **Owner:** subhajeet-patra94
- **URL:** https://github.com/subhajeet-patra94/APOLLO-HOSPITAL-ERP
- **Clone URL:** https://github.com/subhajeet-patra94/APOLLO-HOSPITAL-ERP.git
- **Status:** ✅ Active and Connected

---

## 🌟 NEXT STEPS

1. **Visit your repository:** Open the GitHub URL in browser
2. **Add a README:** Make it look professional on GitHub
3. **Share it:** Add the link to your resume/portfolio
4. **Keep it updated:** Push changes regularly

---

**Need Help?** All commands work from the project folder!

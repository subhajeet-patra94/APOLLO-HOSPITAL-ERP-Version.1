# 🔐 APOLLO HOSPITAL ERP - ADMIN CREDENTIALS

---

## **✅ ADMIN LOGIN CREDENTIALS**

```
╔═════════════════════════════════════════════════════╗
║     APOLLO HOSPITAL MANAGEMENT SYSTEM              ║
║         ADMIN LOGIN CREDENTIALS                    ║
╠═════════════════════════════════════════════════════╣
║                                                   ║
║  User ID:  1                                      ║
║                                                   ║
║  Username: admin                                  ║
║  Password: admin123                               ║
║                                                   ║
║  Email:    admin@hospital.com                     ║
║  Role:     Admin (System Administrator)           ║
║  Status:   Active ✅                              ║
║                                                   ║
║  READY TO USE!                                    ║
║                                                   ║
╚═════════════════════════════════════════════════════╝
```

---

## **📋 QUICK REFERENCE**

| Field | Value |
|-------|-------|
| **Admin ID** | 1 |
| **Username** | `admin` |
| **Password** | `admin123` |
| **Email** | `admin@hospital.com` |
| **Role** | Admin |
| **Status** | Active ✅ |

---

## **👥 OTHER PRE-LOADED USERS**

### **Doctors (3 Available)**

**1. Dr. Rajesh Kumar**
- Doctor ID: 30001
- Specialization: Cardiology
- Consultation Fee: ₹500

**2. Dr. Priya Sharma**
- Doctor ID: 30002
- Specialization: Pediatrics
- Consultation Fee: ₹400

**3. Dr. Anil Verma**
- Doctor ID: 30003
- Specialization: Surgery
- Consultation Fee: ₹600

---

## **🏥 PRE-LOADED RESOURCES**

### **Hospital Beds (9 Total)**
- ICU: 3 beds (₹5000/day each)
- General: 3 beds (₹2000/day each)
- Emergency: 2 beds (₹3000/day each)
- Maternity: 2 beds (₹2500/day each)

---

## **🔐 ADMIN PERMISSIONS**

✅ Full system access  
✅ Register new patients  
✅ Manage doctors  
✅ Allocate beds  
✅ Book appointments  
✅ Generate invoices  
✅ View all reports  
✅ View analytics  
✅ System configuration  

---

## **🛠️ HOW TO CHANGE PASSWORD**

Edit: `src/ERP/HospitalManagementSystem.java`

Line ~100:
```java
User admin = new User(userIdCounter++, "admin", "admin123", "admin@hospital.com", 
                     "System", "Administrator", "Admin");
```

Change `"admin123"` to your desired password, then recompile.

---

## **📊 USER ROLES**

| Role | Access Level | Can Do |
|------|--------------|--------|
| Admin | Full | Everything |
| Doctor | Medium | View patients, manage appointments |
| Patient | Limited | Book appointments, view records |
| Staff | Medium | Support operations |

---

**System Version:** Apollo Hospital ERP v1.0  
**Status:** Ready to Use  
**Last Updated:** December 12, 2025


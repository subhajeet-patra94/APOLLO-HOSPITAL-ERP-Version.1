# 🔐 APOLLO HOSPITAL ERP - ADMIN CREDENTIALS

## **Demo Admin Account**

```
═══════════════════════════════════════════════════
     APOLLO HOSPITAL MANAGEMENT SYSTEM
          Admin Login Credentials
═══════════════════════════════════════════════════

USERNAME: admin
PASSWORD: admin123

═══════════════════════════════════════════════════
```

---

## **Admin Account Details**

| Field | Value |
|-------|-------|
| **User ID** | 1 |
| **Username** | admin |
| **Password** | admin123 |
| **Email** | admin@hospital.com |
| **First Name** | System |
| **Last Name** | Administrator |
| **Role** | Admin |
| **Status** | Active |
| **Department** | Administration |

---

## **Admin Permissions**

✅ Full system access  
✅ User management  
✅ Patient records  
✅ Doctor management  
✅ Appointment oversight  
✅ Billing management  
✅ Hospital reports  
✅ Analytics dashboard  
✅ System configuration  
✅ Data backup  

---

## **How to Login (When Running the System)**

The admin account is **automatically initialized** when the system starts.

In the future, you can:
1. Extend the system with a login interface
2. Use these credentials for authentication
3. Create additional admin/user accounts

---

## **Demo Data Included**

When you run the system, it initializes with:

### **Admin User:**
- User ID: 1
- Username: admin
- Password: admin123
- Status: Active

### **Demo Doctors (3):**
- Dr. Rajesh Kumar (Cardiology)
- Dr. Priya Sharma (Pediatrics)
- Dr. Anil Verma (Surgery)

### **Demo Beds (7):**
- ICU: 2 beds
- General Ward: 3 beds
- Emergency: 2 beds
- Maternity: 0 beds

---

## **Security Notes**

⚠️ **These are demo credentials only**

For production use:
- ✅ Change default password
- ✅ Use strong passwords (min 12 characters)
- ✅ Implement password hashing (BCrypt)
- ✅ Add two-factor authentication
- ✅ Use HTTPS/SSL encryption
- ✅ Implement role-based access control
- ✅ Add audit logging
- ✅ Regular security updates

---

## **Where This is Initialized**

In your code: **HospitalManagementSystem.java**

```java
private void initializeAdminUser() {
    User admin = new User(userIdCounter++, "admin", "admin123", 
                         "admin@hospital.com", 
                         "System", "Administrator", "Admin");
    admin.setRegistrationDate(java.time.LocalDate.now().toString());
    users.add(admin);
}
```

---

## **Test Accounts (Optional)**

For testing, you can create additional accounts:

**Doctor Account:**
```
Username: doctor1
Password: doc123456
Role: Doctor
```

**Patient Account:**
```
Username: patient1
Password: pat123456
Role: Patient
```

**Staff Account:**
```
Username: staff1
Password: stf123456
Role: Staff
```

---

## **Production Authentication (Future)**

When you integrate with Spring Boot, implement:

```java
@PostMapping("/login")
public ResponseEntity<?> login(@RequestBody LoginRequest request) {
    // Authenticate user
    User user = userService.authenticate(request.getUsername(), 
                                        request.getPassword());
    
    // Generate JWT token
    String token = jwtTokenProvider.generateToken(user);
    
    return ResponseEntity.ok(new JwtAuthenticationResponse(token));
}
```

---

## **Emergency Access**

If you forget credentials:
1. The system reinitializes on each run
2. Default admin account is always created
3. No persistent storage yet (in-memory only)

---

## **Summary**

✅ Admin Username: `admin`  
✅ Admin Password: `admin123`  
✅ Status: Active  
✅ Role: Full administrative access  
✅ Email: admin@hospital.com  

---

**These credentials work in the demo system!** 🔐

When you add database persistence and authentication:
- Update the User.java class
- Add password hashing
- Implement login interface
- Add security measures

---


# 📋 APOLLO HOSPITAL ERP - COMPLETE CREDENTIALS & ACCESS GUIDE

---

## **🔐 ADMIN LOGIN CREDENTIALS**

```
┌──────────────────────────────────────────┐
│        ADMIN ACCOUNT DETAILS             │
├──────────────────────────────────────────┤
│                                          │
│  Username:  admin                        │
│  Password:  admin123                     │
│  User ID:   1                            │
│  Role:      Administrator                │
│  Email:     admin@hospital.com           │
│  Status:    Active                       │
│                                          │
└──────────────────────────────────────────┘
```

---

## **👥 OTHER DEFAULT ACCOUNTS**

### **Doctor Accounts (Pre-loaded)**

**Doctor 1:**
```
Doctor ID: 30001
Name: Rajesh Kumar
Specialization: Cardiology
Consultation Fee: ₹500
Status: Available
```

**Doctor 2:**
```
Doctor ID: 30002
Name: Priya Sharma
Specialization: Pediatrics
Consultation Fee: ₹400
Status: Available
```

**Doctor 3:**
```
Doctor ID: 30003
Name: Anil Verma
Specialization: Surgery
Consultation Fee: ₹600
Status: Available
```

---

## **🏥 HOSPITAL DEMO DATA**

### **Beds Available:**
- ICU: 3 beds
- General Ward: 3 beds
- Emergency: 2 beds
- Maternity: 2 beds
- **Total: 10 beds**

### **Initial Bed List:**
```
Bed 1: ICU-101 (₹5000/day)
Bed 2: ICU-102 (₹5000/day)
Bed 3: GEN-101 (₹2000/day)
Bed 4: GEN-102 (₹2000/day)
Bed 5: GEN-103 (₹2000/day)
Bed 6: EMG-101 (₹8000/day)
Bed 7: EMG-102 (₹8000/day)
Bed 8: MAT-101 (₹3000/day)
Bed 9: MAT-102 (₹3000/day)
Bed 10: MAT-103 (₹3000/day)
```

---

## **📊 DEFAULT SYSTEM CONFIGURATION**

### **Hospital Settings:**
- Hospital Name: Apollo Hospital
- Version: 1.0
- Environment: Demo
- Data Storage: In-Memory (ArrayList)
- Database: Not yet connected

### **System Features:**
- ✅ Patient Management
- ✅ Doctor Management
- ✅ Appointment Scheduling
- ✅ Bed Management
- ✅ Billing System
- ✅ Analytics Dashboard

---

## **🔑 ACCESS LEVELS**

### **Admin Role (Current):**
```
Username: admin
Password: admin123
Access: FULL (All features)
```

### **Doctor Role (For Future):**
```
Suggested Username: doctor[number]
Suggested Password: [secure_password]
Access: Patient care, Appointments, Prescriptions
```

### **Patient Role (For Future):**
```
Suggested Username: patient[number]
Suggested Password: [secure_password]
Access: View own records, Book appointments
```

### **Staff Role (For Future):**
```
Suggested Username: staff[number]
Suggested Password: [secure_password]
Access: Records, Billing, Reports
```

---

## **💾 HOW CREDENTIALS ARE INITIALIZED**

When you run the system:

```java
// Auto-initialized admin user
User admin = new User(1, "admin", "admin123", "admin@hospital.com", 
                     "System", "Administrator", "Admin");
users.add(admin);

// Auto-initialized doctors
Doctor doctor1 = new Doctor(30001, "Rajesh Kumar", "Cardiology", 500, 15);
doctors.add(doctor1);

// Auto-initialized beds
Bed bed1 = new Bed(1, "ICU-101", "ICU", 5000);
beds.add(bed1);
```

---

## **🚀 USING ADMIN ACCOUNT**

### **In Current Demo System:**
The admin account is **automatically active** when you run:
```bash
java -cp bin ERP.ApolloHospital
```

### **For Future Web Interface:**
Implement login with these credentials:
```java
@PostMapping("/login")
public ResponseEntity<?> login(@RequestBody LoginRequest request) {
    // Validate username: admin
    // Validate password: admin123
    // Return JWT token or session
}
```

---

## **⚠️ SECURITY RECOMMENDATIONS**

For production deployment:

1. **Password Security:**
   - ✅ Change default password
   - ✅ Use strong passwords (min 12 characters)
   - ✅ Hash passwords with BCrypt
   - ✅ Add salt for security

2. **Authentication:**
   - ✅ Implement JWT tokens
   - ✅ Add session management
   - ✅ Use HTTPS/SSL only
   - ✅ Implement OAuth 2.0

3. **Authorization:**
   - ✅ Role-based access control (RBAC)
   - ✅ Granular permissions
   - ✅ Resource-level access
   - ✅ API endpoint protection

4. **Audit & Logging:**
   - ✅ Log all login attempts
   - ✅ Track user actions
   - ✅ Monitor data changes
   - ✅ Alert on suspicious activity

5. **Data Protection:**
   - ✅ Encrypt sensitive data
   - ✅ Use database encryption
   - ✅ Regular backups
   - ✅ Data retention policies

---

## **📱 DEMO WORKFLOW**

### **Login Process:**
```
1. User opens application
2. Admin credentials auto-loaded (in-memory)
3. System displays welcome banner
4. Admin can:
   - Register patients
   - Manage doctors
   - Book appointments
   - Allocate beds
   - Generate invoices
   - View analytics
```

### **Demo Operations:**
```
Sample Patient: Vikram Singh
Sample Doctor: Rajesh Kumar (Cardiology)
Sample Bed: ICU-101
Sample Invoice: ₹25,500
```

---

## **🔄 CREDENTIALS PERSISTENCE**

### **Current System (In-Memory):**
- Data exists only during runtime
- Lost when program ends
- Credentials reset on restart
- Perfect for demo/testing

### **Future (With Database):**
- Implement User table in PostgreSQL
- Use hashed passwords
- Enable persistent login
- Add remember-me functionality

---

## **📚 RELATED FILES**

For more information, see:
- `ADMIN_CREDENTIALS.md` - Detailed admin info
- `User.java` - User model with credentials
- `HospitalManagementSystem.java` - Initialization code
- `README.md` - System overview
- `IMPLEMENTATION_GUIDE.md` - How to extend

---

## **✅ QUICK REFERENCE**

```
┌─────────────────────────────────┐
│  ADMIN LOGIN                    │
├─────────────────────────────────┤
│  Username: admin                │
│  Password: admin123             │
│  Status:   Active ✅            │
│  Access:   FULL                 │
└─────────────────────────────────┘

┌─────────────────────────────────┐
│  DEMO DATA                      │
├─────────────────────────────────┤
│  Doctors:     3 available       │
│  Beds:        10 available      │
│  Demo Demo:   Auto-initialized  │
│  Status:      Ready to use ✅   │
└─────────────────────────────────┘
```

---

## **🎯 NEXT STEPS**

1. **Run the demo** with admin account automatically active
2. **Understand the system** using the demo data
3. **Extend the system** by adding login UI
4. **Connect database** for persistent credentials
5. **Deploy to production** with security measures

---

**All credentials are ready and system is fully functional!** ✅


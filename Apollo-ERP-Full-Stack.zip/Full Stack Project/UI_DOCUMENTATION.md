# Apollo Hospital Management System - UI Documentation

## 🎨 UI Components Overview

This project contains a complete HTML/CSS UI for the Apollo Hospital Management ERP System.

## 📁 File Structure

```
Full Stack Project/
├── index.html              # Main landing page
├── login.html              # User authentication page
├── dashboard.html          # Admin dashboard
├── css/
│   ├── style.css          # Main stylesheet with global styles
│   ├── login.css          # Login page specific styles
│   └── dashboard.css      # Dashboard specific styles
└── js/
    └── main.js            # Main JavaScript functionality
```

## 🌟 Pages Created

### 1. **index.html** - Landing Page
- **Features:**
  - Responsive navigation bar with mobile hamburger menu
  - Hero section with gradient overlay and call-to-action buttons
  - Statistics cards (Patients, Doctors, Beds, Appointments)
  - Features grid showcasing 6 main modules
  - Quick access section for common actions
  - Technology stack display
  - Comprehensive footer with links and contact info
  
- **Design Highlights:**
  - Modern gradient backgrounds
  - Smooth animations and transitions
  - Card-based layout with hover effects
  - Fully responsive design

### 2. **login.html** - Authentication Page
- **Features:**
  - Split-screen design with branding section
  - User type selection (Admin, Doctor, Staff, Patient)
  - Username/Email and password inputs
  - Password visibility toggle
  - Remember me checkbox
  - Demo credentials display
  - Forgot password link
  - Register link for new users
  
- **Demo Credentials:**
  - Admin: `admin@apollo.com` / `admin123`
  - Doctor: `doctor@apollo.com` / `doctor123`

### 3. **dashboard.html** - Main Dashboard
- **Features:**
  - Welcome header with user name
  - Action buttons (Refresh, Export Report)
  - 4 key statistics cards with trend indicators
  - Real-time bed occupancy status with progress bars
  - Recent appointments list
  - Quick actions grid (6 action buttons)
  - Doctor availability status
  - Recent admissions list
  
- **Interactive Elements:**
  - Auto-refresh every 5 minutes
  - Session management
  - Logout functionality
  - Loading indicators
  - Success/error notifications

## 🎨 Design System

### Color Palette
```css
Primary Color: #2563eb (Blue)
Secondary Color: #1e40af (Dark Blue)
Accent Color: #3b82f6 (Light Blue)
Success Color: #10b981 (Green)
Warning Color: #f59e0b (Orange)
Danger Color: #ef4444 (Red)
Dark Color: #1f2937 (Gray)
Light Color: #f3f4f6 (Light Gray)
```

### Typography
- Font Family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif
- Headings: Bold weight, varying sizes
- Body Text: Regular weight, 1.6 line-height

### Spacing
- Container: Max-width 1200px, centered
- Padding: Consistent 20px on containers
- Gaps: 1rem to 3rem based on component

### Components
1. **Navigation Bar**
   - Sticky positioning
   - Gradient background
   - Responsive hamburger menu
   - Active link highlighting

2. **Cards**
   - White background
   - Subtle shadows
   - Border radius: 15px
   - Hover effects with transform

3. **Buttons**
   - Multiple variants (primary, secondary, action)
   - Icon + text combination
   - Smooth transitions
   - Hover animations

4. **Status Badges**
   - Color-coded (success, warning, danger)
   - Rounded corners
   - Small padding

5. **Progress Bars**
   - Animated fill
   - Color-coded by status
   - Percentage display

## 📱 Responsive Breakpoints

- **Desktop**: 1200px and above
- **Tablet**: 768px - 1199px
- **Mobile**: 767px and below
- **Small Mobile**: 600px and below

### Mobile Optimizations
- Hamburger menu navigation
- Single column layouts
- Stacked cards and grids
- Touch-friendly button sizes
- Reduced font sizes for small screens

## ⚡ JavaScript Features

### main.js Functionality
1. **Mobile Menu Toggle**
   - Hamburger icon animation
   - Slide-in menu on mobile

2. **Smooth Scrolling**
   - Anchor link smooth scroll behavior

3. **Active Navigation**
   - Highlights current section on scroll

4. **Scroll Animations**
   - Intersection Observer for fade-in effects

5. **Form Validation**
   - Real-time input validation
   - Error message display

6. **Notifications**
   - Toast-style notifications
   - Success/error variants
   - Auto-dismiss after 3 seconds

7. **Loading Spinner**
   - Full-screen loading overlay
   - Animated spinner

### Dashboard Specific
1. **Session Management**
   - Check login status
   - Store user information
   - Logout functionality

2. **Auto-refresh**
   - Dashboard data refresh every 5 minutes

## 🚀 How to Use

### Opening the Application
1. Open `index.html` in any modern web browser
2. Navigate through pages using the menu
3. Click "Login" to access the login page
4. Use demo credentials to access the dashboard

### Testing Login
```
URL: login.html
Username: admin@apollo.com
Password: admin123
```

### Features to Test
- ✅ Responsive navigation (resize browser)
- ✅ Mobile menu (< 768px width)
- ✅ Login with demo credentials
- ✅ Dashboard statistics display
- ✅ Bed occupancy progress bars
- ✅ Quick action buttons
- ✅ Logout functionality

## 🔧 Customization

### Changing Colors
Edit CSS variables in `css/style.css`:
```css
:root {
    --primary-color: #2563eb;  /* Change this */
    --secondary-color: #1e40af; /* Change this */
    /* ... other colors */
}
```

### Adding New Pages
1. Create new HTML file
2. Include CSS: `<link rel="stylesheet" href="css/style.css">`
3. Include JS: `<script src="js/main.js"></script>`
4. Copy navigation structure from existing pages
5. Add to navigation menu

### Modifying Dashboard Cards
Edit `dashboard.html` and update:
- `.stat-card` for statistics
- `.dashboard-card` for information sections
- `.action-btn` for quick actions

## 🌐 Browser Support

- ✅ Chrome (Latest)
- ✅ Firefox (Latest)
- ✅ Safari (Latest)
- ✅ Edge (Latest)
- ✅ Opera (Latest)

## 📦 External Dependencies

### Font Awesome Icons (CDN)
```html
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
```

**Icons Used:**
- Hospital: `fa-hospital-alt`
- User Medical: `fa-user-injured`
- Doctor: `fa-user-md`
- Calendar: `fa-calendar-check`
- Bed: `fa-bed`
- Invoice: `fa-file-invoice-dollar`
- And many more...

## 🎯 Future Enhancements

### Additional Pages to Create
- [ ] patients.html - Patient management page
- [ ] doctors.html - Doctor management page
- [ ] appointments.html - Appointment scheduling
- [ ] beds.html - Bed management interface
- [ ] billing.html - Billing and invoicing
- [ ] register-patient.html - Patient registration form
- [ ] book-appointment.html - Appointment booking form
- [ ] admit-patient.html - Patient admission form
- [ ] generate-bill.html - Bill generation form
- [ ] register.html - New user registration
- [ ] forgot-password.html - Password recovery

### Backend Integration
- Connect to Java backend API
- Real database queries
- User authentication system
- Real-time data updates
- File upload functionality

### Enhanced Features
- Dark mode toggle
- Multi-language support
- Print functionality
- PDF export
- Chart visualizations (Chart.js)
- Real-time notifications
- Search and filter functionality

## 📄 License

This UI is part of the Apollo Hospital Management ERP System.
All rights reserved © 2025

## 👨‍💻 Developer Notes

- All CSS uses modern Flexbox and Grid layouts
- JavaScript uses ES6+ features
- No jQuery dependency
- Vanilla JavaScript for better performance
- CSS animations for smooth transitions
- Mobile-first responsive design approach

## 🆘 Support

For issues or questions about the UI:
1. Check browser console for errors
2. Verify all CSS/JS files are linked correctly
3. Test in different browsers
4. Check responsive breakpoints

---

**Status:** ✅ UI Base Complete
**Last Updated:** December 14, 2025
**Version:** 1.0.0

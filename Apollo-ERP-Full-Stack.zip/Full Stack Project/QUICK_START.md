# ⚡ QUICK START - RUN IN 30 SECONDS

## **FASTEST WAY - METHOD 1: ECLIPSE IDE**

### 👇 Do This:

1. **Open Eclipse**
   - Double-click Eclipse icon

2. **Open Project**
   - File → Open Projects from File System
   - Path: `C:\Users\subha\eclipse-workspace\Full Stack Project`
   - Click Finish

3. **Find the Program**
   ```
   Full Stack Project
   └─ src
      └─ ERP
         └─ ApolloHospital.java  ← RIGHT-CLICK HERE
   ```

4. **Run It**
   - Right-click ApolloHospital.java
   - **Run As → Java Application**

5. **Watch It Run**
   - See output in Console tab at bottom

---

## **ALTERNATIVE: COMMAND PROMPT (1 COMMAND)**

### Open Command Prompt and paste this:
```bash
cd C:\Users\subha\eclipse-workspace\Full Stack Project && java -cp bin ERP.ApolloHospital
```

---

## **WHAT YOU'LL SEE (30 SECONDS)**

```
╔════════════════════════════════════════════════════════╗
║    APOLLO HOSPITAL MANAGEMENT ERP SYSTEM v1.0         ║
║    Full Stack Hospital Management Solution           ║
╚════════════════════════════════════════════════════════╝

Welcome to Apollo Hospital Management System
Integrated Patient, Bed, Doctor & Billing Modules

========== DEMO: Registering New Patient ==========
✓ Patient Registered: Patient{patientId=1001, firstName='Vikram', lastName='Singh', email='vikram@email.com', phone='9876543210', status='Active'}

========== DEMO: Booking Appointment ==========
✓ Appointment Booked: Appointment{appointmentId=5001, patientId=1001, doctorId=30001, appointmentDate='2025-12-15', appointmentTime='10:00 AM', status='Scheduled', department='Cardiology'}
  Doctor: Rajesh Kumar
  Consultation Fee: ₹500.0

========== DEMO: Admitting Patient to Bed ==========
✓ Patient Admitted to Bed: ICU-101
  Ward: ICU
  Daily Rate: ₹5000.0

========== DEMO: Creating Billing Invoice ==========
✓ Invoice Created: #2001
✓ Charges Added - Bed (5 days @ ₹5000): ₹25000
✓ Charges Added - Consultation: ₹500
  Total Invoice Amount: ₹25500

========== DEMO: System Statistics ==========
========== APOLLO HOSPITAL - SYSTEM STATUS ==========
Total Active Patients: 1
Total Registered Doctors: 3
Total Appointments: 1
Available ICU Beds: 2
Available General Beds: 3
Available Emergency Beds: 2
Total Revenue: ₹0.0
Outstanding Amount: ₹0.0

========== DEMO: Available Doctors ==========
✓ Rajesh Kumar | Specialization: Cardiology | Status: Available | Consultation: ₹500.0
✓ Priya Sharma | Specialization: Pediatrics | Status: Available | Consultation: ₹400.0
✓ Anil Verma | Specialization: Surgery | Status: Available | Consultation: ₹600.0

========== DEMO: Bed Occupancy Report ==========
✓ Maternity: 0 beds occupied
✓ General Ward: 0 beds occupied
✓ ICU: 1 beds occupied
✓ Emergency: 0 beds occupied

========== DEMO: Financial Summary ==========
✓ Total Revenue: ₹0.0
✓ Outstanding Amount: ₹0.0
✓ Pending Invoices: 1

╔════════════════════════════════════════════════════════╗
║  DEMO COMPLETED SUCCESSFULLY                          ║
║  System is ready for full-scale deployment            ║
╚════════════════════════════════════════════════════════╝
```

---

## **WHAT THE DEMO SHOWS**

| Step | What Happens | System Output |
|------|--------------|---------------|
| 1 | **Patient Registration** | New patient "Vikram Singh" created (ID: 1001) |
| 2 | **Doctor Lookup** | System finds Dr. Rajesh Kumar (Cardiology) |
| 3 | **Appointment Booking** | Appointment #5001 booked for Dec 15, 2025 |
| 4 | **Bed Allocation** | Patient admitted to ICU-101 bed |
| 5 | **Billing** | Invoice #2001 generated with ₹25,500 total |
| 6 | **Analytics** | Shows 1 patient, 3 doctors, 7 beds, 1 appointment |
| 7 | **Reports** | Bed occupancy and financial summary displayed |

---

## **SYSTEM FEATURES IN ACTION**

✅ **Patient Management**
- Register new patients
- Track patient status
- Manage medical records

✅ **Doctor Management**
- View available doctors
- Check specializations
- See consultation fees

✅ **Appointment System**
- Book appointments
- Schedule with doctors
- Manage dates and times

✅ **Bed Management**
- Allocate hospital beds
- Track occupancy
- Manage different wards (ICU, General, Emergency, Maternity)

✅ **Billing System**
- Generate invoices
- Calculate charges
- Track payments

✅ **Analytics Dashboard**
- System statistics
- Bed occupancy reports
- Financial summaries

---

## **TROUBLESHOOTING**

### Problem: Can't find the file
**Solution:** Make sure you're in the right folder
```bash
cd C:\Users\subha\eclipse-workspace\Full Stack Project
dir bin\ERP\ApolloHospital.class
```

### Problem: "java not found"
**Solution:** Install Java or add it to PATH
- Download from: https://www.oracle.com/java/technologies/javase-downloads.html
- Restart your computer after install

### Problem: Nothing happens when I run it
**Solution:** Check Eclipse Console tab
- Bottom of Eclipse window
- Click "Console" tab
- You should see the output there

---

## **TRY DIFFERENT SCENARIOS**

You can run the program multiple times and each time you get:
- A new patient registration
- A fresh appointment booking
- Different scenarios in the demo

Run it 3-4 times to see how the system handles multiple patients!

---

## **NEXT STEPS (OPTIONAL)**

After seeing the demo, you can:

1. **Modify the Code** - Change patient names, dates, etc.
2. **Add Features** - Extend the system
3. **Database Integration** - Connect to PostgreSQL (advanced)
4. **Web Interface** - Add Spring Boot + React (advanced)

For now, just enjoy the demo! 🎉

---

**Your Apollo Hospital ERP System is ready to run!** 🏥✨


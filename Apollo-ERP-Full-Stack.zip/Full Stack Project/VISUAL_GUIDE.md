# 📊 VISUAL GUIDE - HOW THE SYSTEM WORKS

## **ARCHITECTURE DIAGRAM**

```
┌─────────────────────────────────────────────────────────────┐
│                    APOLLO HOSPITAL ERP                      │
│                     SYSTEM FLOW DIAGRAM                     │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│          USER INTERACTION (What You See & Do)              │
└─────────────────────────────────────────────────────────────┘
                              ▼
                    ╔═════════════════════╗
                    ║   DISPLAY WELCOME   ║
                    ║   HOSPITAL BANNER   ║
                    ╚═════════════════════╝
                              ▼
        ┌─────────────────────────────────────────┐
        │                                         │
        ▼                                         ▼
   ┌────────────────┐                  ┌──────────────────┐
   │  PATIENT DATA  │                  │  DOCTOR DATA     │
   │                │                  │                  │
   │ ID: 1001       │                  │ ID: 30001        │
   │ Name: Vikram   │                  │ Name: Rajesh     │
   │ Email: ...     │                  │ Specialization:  │
   │ Phone: ...     │                  │ Cardiology       │
   │ Status: Active │                  │ Fee: ₹500        │
   └────────────────┘                  └──────────────────┘
        ▼                                         ▼
        └──────────────┬──────────────────────────┘
                       ▼
            ┌──────────────────────────┐
            │  APPOINTMENT BOOKING     │
            │                          │
            │ Appointment ID: 5001     │
            │ Date: 2025-12-15         │
            │ Time: 10:00 AM           │
            │ Status: Scheduled        │
            └──────────────────────────┘
                       ▼
            ┌──────────────────────────┐
            │  BED ALLOCATION          │
            │                          │
            │ Bed: ICU-101             │
            │ Ward: ICU                │
            │ Rate: ₹5000/day          │
            │ Status: Occupied         │
            └──────────────────────────┘
                       ▼
            ┌──────────────────────────┐
            │  BILLING CALCULATION     │
            │                          │
            │ Invoice ID: 2001         │
            │ Bed Charges: ₹25,000     │
            │ Consultation: ₹500       │
            │ Total: ₹25,500           │
            └──────────────────────────┘
                       ▼
        ┌──────────────────────────────────┐
        │                                  │
        ▼                                  ▼
  ┌────────────────────┐        ┌────────────────────┐
  │  ANALYTICS &       │        │  FINANCIAL         │
  │  STATISTICS        │        │  SUMMARY           │
  │                    │        │                    │
  │ Patients: 1        │        │ Revenue: ₹0        │
  │ Doctors: 3         │        │ Outstanding: ₹0    │
  │ Beds: 7 total      │        │ Pending: 1         │
  │ Appointments: 1    │        │                    │
  └────────────────────┘        └────────────────────┘
```

---

## **DATA FLOW DIAGRAM**

```
INPUT (Program Start)
       │
       ▼
┌──────────────────────────┐
│ APOLLOHOSPITAL CLASS     │
│ - main() entry point     │
│ - Create HMS instance    │
│ - Initialize system data │
└──────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────┐
│ HOSPITALMANGEMENTSYSTEM CLASS            │
│ (Central Coordinator - Orchestrator)     │
│                                          │
│ Manages:                                 │
│ ├─ Patient operations                    │
│ ├─ Doctor management                     │
│ ├─ Appointment scheduling                │
│ ├─ Bed allocation                        │
│ ├─ Billing operations                    │
│ └─ System analytics                      │
└──────────────────────────────────────────┘
       │
       ├─────────────────────────────┬──────────────────┬────────────┐
       │                             │                  │            │
       ▼                             ▼                  ▼            ▼
   ┌─────────────┐     ┌─────────────────┐  ┌──────────────┐  ┌──────────┐
   │ PATIENT     │     │ DOCTOR LOOKUP   │  │ BED MGMT     │  │ BILLING  │
   │ SERVICE     │     │ (Doctor objects)│  │ SERVICE      │  │ SERVICE  │
   │             │     │                 │  │              │  │          │
   │ Operations: │     │ Search doctors  │  │ Operations:  │  │ Create   │
   │ ├─Register  │     │ by specialty    │  │ ├─ Get avail │  │ invoices │
   │ ├─Update    │     │ Get fee info    │  │ ├─ Allocate  │  │ Add      │
   │ ├─Search    │     │ Check status    │  │ ├─ Discharge │  │ charges  │
   │ └─Discharge │     │                 │  │ └─ Report    │  │ Calculate│
   └─────────────┘     └─────────────────┘  └──────────────┘  └──────────┘
       │                     │                      │                │
       └─────────────────────┼──────────────────────┼────────────────┘
                             │
                             ▼
                    ┌──────────────────────┐
                    │ DATA COLLECTIONS     │
                    │ (In-Memory Storage)  │
                    │                      │
                    │ ├─ patients List     │
                    │ ├─ doctors List      │
                    │ ├─ appointments List │
                    │ ├─ beds List         │
                    │ ├─ invoices List     │
                    │ ├─ prescriptions     │
                    │ └─ users List        │
                    └──────────────────────┘
                             │
                             ▼
                    ┌──────────────────────┐
                    │ OUTPUT TO CONSOLE    │
                    │                      │
                    │ ├─ Welcome message   │
                    │ ├─ Demo sections     │
                    │ ├─ Patient info      │
                    │ ├─ Appointment data  │
                    │ ├─ Invoice details   │
                    │ ├─ Analytics report  │
                    │ └─ Success message   │
                    └──────────────────────┘
```

---

## **CLASS HIERARCHY**

```
┌─────────────────────────────────────────────────────────┐
│                  DATA MODELS (Entities)                │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌──────────┐  ┌────────┐  ┌──────┐  ┌──────────────┐ │
│  │ Patient  │  │ Doctor │  │ Bed  │  │ Appointment  │ │
│  │          │  │        │  │      │  │              │ │
│  │ ├─ ID    │  │ ├─ ID  │  │├─ ID │  │ ├─ ID        │ │
│  │ ├─ Name  │  │ ├─ Name│  ││   # │  │ ├─ PatientID │ │
│  │ ├─ Email │  │ ├─ Spec│  │├─Ward│  │ ├─ DoctorID  │ │
│  │ ├─ Phone │  │ ├─ Fee │  │└─Rate│  │ ├─ Date      │ │
│  │ └─ Status│  │ └─Status  └──────┘  │ ├─ Time      │ │
│  └──────────┘  └────────┘             │ └─ Status    │ │
│                                       └──────────────┘ │
│  ┌──────────┐  ┌──────────────┐  ┌──────────┐        │
│  │Billing   │  │Prescription  │  │User      │        │
│  │          │  │              │  │          │        │
│  │ ├─ ID    │  │ ├─ ID        │  │ ├─ ID    │        │
│  │ ├─ Amount│  │ ├─ Medication│  │ ├─ Name  │        │
│  │ ├─ Date  │  │ ├─ Dosage    │  │ ├─ Role  │        │
│  │ └─ Status│  │ └─ Duration  │  │ └─ Status│        │
│  └──────────┘  └──────────────┘  └──────────┘        │
│                                                         │
└─────────────────────────────────────────────────────────┘
                            ▲
                            │
            (Used by Services)
                            │
┌─────────────────────────────────────────────────────────┐
│               BUSINESS LOGIC (Services)                │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌──────────────────┐  ┌────────────────────┐          │
│  │PatientService    │  │BedService          │          │
│  │                  │  │                    │          │
│  │├─registerPatient │  │├─getAvailableBeds  │          │
│  │├─getPatientById  │  │├─admitPatient      │          │
│  │├─searchPatients  │  │├─dischargePatient  │          │
│  │└─dischargePatient│  │└─getBedReport      │          │
│  └──────────────────┘  └────────────────────┘          │
│                                                         │
│  ┌──────────────────────┐  ┌──────────────────┐        │
│  │AppointmentService    │  │BillingService    │        │
│  │                      │  │                  │        │
│  │├─bookAppointment     │  │├─createInvoice   │        │
│  │├─rescheduleAppt      │  │├─addCharges      │        │
│  │├─cancelAppointment   │  │├─calculateTotal  │        │
│  │└─getAppointments     │  │└─getRevenue      │        │
│  └──────────────────────┘  └──────────────────┘        │
│                                                         │
└─────────────────────────────────────────────────────────┘
                            ▲
                            │
            (Coordinated by HospitalManagementSystem)
                            │
┌─────────────────────────────────────────────────────────┐
│          SYSTEM COORDINATOR CLASS                      │
│     HospitalManagementSystem (Orchestrator)            │
│                                                         │
│ ├─ initializeSystemData()                              │
│ ├─ registerNewPatient()                                │
│ ├─ bookAppointment()                                   │
│ ├─ admitPatientToBed()                                 │
│ ├─ createInvoice()                                     │
│ ├─ getSystemStatistics()                               │
│ ├─ displaySystemStatus()                               │
│ └─ getBedOccupancy()                                   │
│                                                         │
└─────────────────────────────────────────────────────────┘
                            ▲
                            │
                   Called by ApolloHospital
                            │
┌─────────────────────────────────────────────────────────┐
│              ENTRY POINT CLASS                         │
│              ApolloHospital (main)                     │
│                                                         │
│ ├─ displayWelcomeMessage()                              │
│ ├─ demonstrateSystem()                                  │
│ │   ├─ Demo patient registration                        │
│ │   ├─ Demo appointment booking                         │
│ │   ├─ Demo bed admission                               │
│ │   ├─ Demo billing                                     │
│ │   ├─ Demo statistics                                  │
│ │   ├─ Demo doctor list                                 │
│ │   ├─ Demo occupancy report                            │
│ │   └─ Demo financial summary                           │
│ │                                                        │
│ └─ main(String[] args)  ← STARTS HERE                   │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## **EXECUTION FLOW DIAGRAM**

```
START
  │
  ▼
┌─────────────────────────────────────┐
│ java -cp bin ERP.ApolloHospital     │
│ (Or Run As Java Application)        │
└─────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────┐
│ ApolloHospital.main() executed      │
└─────────────────────────────────────┘
  │
  ├─► new ApolloHospital()
  │   └─► new HospitalManagementSystem()
  │       └─► Initialize all data (doctors, beds, etc.)
  │
  ├─► displayWelcomeMessage()
  │   └─► Print header banner
  │
  └─► demonstrateSystem()
      │
      ├─► DEMO 1: registerNewPatient()
      │   └─► PatientService.registerPatient()
      │
      ├─► DEMO 2: getDoctorsBySpecialization()
      │   └─► Search doctors list
      │
      ├─► DEMO 3: bookAppointment()
      │   └─► AppointmentService.bookAppointment()
      │
      ├─► DEMO 4: getAvailableBeds()
      │   └─► BedService.getAvailableBeds()
      │
      ├─► DEMO 5: admitPatientToBed()
      │   └─► Update bed occupancy
      │
      ├─► DEMO 6: createInvoice()
      │   └─► BillingService.createInvoice()
      │
      ├─► DEMO 7: displaySystemStatus()
      │   └─► Show all statistics
      │
      ├─► DEMO 8: getAllDoctors()
      │   └─► Display all doctors
      │
      ├─► DEMO 9: getBedOccupancy()
      │   └─► Show occupancy report
      │
      └─► DEMO 10: Financial Summary
          └─► Display revenue & outstanding

END - "Demo Completed Successfully"
```

---

## **MEMORY/DATA STORAGE DIAGRAM**

```
┌───────────────────────────────────────────────────────┐
│        IN-MEMORY DATA STORAGE (Collections)           │
├───────────────────────────────────────────────────────┤
│                                                       │
│  ┌─────────────────────────────────────────────┐    │
│  │ List<Patient> patients                      │    │
│  ├─────────────────────────────────────────────┤    │
│  │ [0] Patient{ID:1001, Name:Vikram, ...}     │    │
│  │ [1] Patient{ID:1002, Name:Priya, ...}      │    │
│  │ [2] Patient{ID:1003, Name:Anil, ...}       │    │
│  │ ... (grows as more patients register)      │    │
│  └─────────────────────────────────────────────┘    │
│                                                       │
│  ┌─────────────────────────────────────────────┐    │
│  │ List<Doctor> doctors                        │    │
│  ├─────────────────────────────────────────────┤    │
│  │ [0] Doctor{ID:30001, Name:Rajesh, ...}     │    │
│  │ [1] Doctor{ID:30002, Name:Priya, ...}      │    │
│  │ [2] Doctor{ID:30003, Name:Anil, ...}       │    │
│  │ (Fixed 3 doctors in demo)                  │    │
│  └─────────────────────────────────────────────┘    │
│                                                       │
│  ┌─────────────────────────────────────────────┐    │
│  │ List<Bed> beds                              │    │
│  ├─────────────────────────────────────────────┤    │
│  │ [0] Bed{ID:1, BedNo:ICU-101, Ward:ICU}     │    │
│  │ [1] Bed{ID:2, BedNo:ICU-102, Ward:ICU}     │    │
│  │ [2] Bed{ID:3, BedNo:GEN-101, Ward:General} │    │
│  │ ... (7 total beds)                         │    │
│  └─────────────────────────────────────────────┘    │
│                                                       │
│  ┌─────────────────────────────────────────────┐    │
│  │ List<Appointment> appointments              │    │
│  ├─────────────────────────────────────────────┤    │
│  │ [0] Appointment{ID:5001, PatientID:1001...}│    │
│  │ [1] Appointment{ID:5002, PatientID:1002...}│    │
│  │ ... (grows with new appointments)          │    │
│  └─────────────────────────────────────────────┘    │
│                                                       │
│  ┌─────────────────────────────────────────────┐    │
│  │ List<Billing> invoices                      │    │
│  ├─────────────────────────────────────────────┤    │
│  │ [0] Billing{ID:2001, Amount:25500, ...}    │    │
│  │ [1] Billing{ID:2002, Amount:15000, ...}    │    │
│  │ ... (grows with new invoices)              │    │
│  └─────────────────────────────────────────────┘    │
│                                                       │
│  ⚠️  ALL DATA STORED IN MEMORY                       │
│  ❌ DATA LOST WHEN PROGRAM ENDS                      │
│  ✅ PERFECT FOR TESTING & DEMO                      │
│                                                       │
└───────────────────────────────────────────────────────┘
```

---

## **PATIENT JOURNEY DIAGRAM**

```
Patient Arrives at Hospital
        │
        ▼
┌──────────────────┐
│ REGISTRATION     │
│                  │
│ Vikram Singh     │
│ Email: ...       │
│ Phone: ...       │
│ Gets ID: 1001    │
└──────────────────┘
        │
        ▼
┌──────────────────┐
│ CONSULTATION     │
│                  │
│ Select: Cardio   │
│ Doctor: Rajesh   │
│ Fee: ₹500        │
│ Date: 2025-12-15 │
│ Time: 10:00 AM   │
│ Appt ID: 5001    │
└──────────────────┘
        │
        ▼
┌──────────────────┐
│ ADMISSION        │
│                  │
│ Allocated: ICU   │
│ Bed: ICU-101     │
│ Rate: ₹5000/day  │
│ Status: Occupied │
└──────────────────┘
        │
        ▼
┌──────────────────┐
│ TREATMENT        │
│ & CARE           │
│                  │
│ 5 days stay      │
│ Under ICU care   │
└──────────────────┘
        │
        ▼
┌──────────────────┐
│ BILLING &        │
│ PAYMENT          │
│                  │
│ Invoice: #2001   │
│ Bed: ₹25,000     │
│ Consult: ₹500    │
│ Total: ₹25,500   │
│ Status: Pending  │
└──────────────────┘
        │
        ▼
┌──────────────────┐
│ DISCHARGE        │
│                  │
│ Bed Released     │
│ Data Archived    │
│ Discharge Date   │
│ 2025-12-20       │
└──────────────────┘
        │
        ▼
  PATIENT LEAVES
```

---

## **TECHNICAL STACK LAYERS**

```
┌─────────────────────────────────────────────────────────┐
│                 PRESENTATION LAYER                      │
│        (Console Output to User)                         │
│                                                         │
│  System.out.println() ← Displays results                │
│  User sees formatted output with ✓ and ₹ symbols      │
└─────────────────────────────────────────────────────────┘
                            ▲
                            │
                   (Calls from services)
                            │
┌─────────────────────────────────────────────────────────┐
│              APPLICATION/BUSINESS LOGIC LAYER           │
│                                                         │
│  ├─ ApolloHospital.java (Demo orchestrator)             │
│  ├─ HospitalManagementSystem.java (System coordinator)  │
│  ├─ PatientService.java (Patient operations)            │
│  ├─ BedService.java (Bed operations)                    │
│  ├─ AppointmentService.java (Appointment operations)    │
│  └─ BillingService.java (Billing operations)            │
│                                                         │
│  Functions: All business logic & calculations           │
└─────────────────────────────────────────────────────────┘
                            ▲
                            │
                   (Uses models)
                            │
┌─────────────────────────────────────────────────────────┐
│                DATA MODEL LAYER                         │
│                                                         │
│  ├─ Patient.java       ├─ Appointment.java              │
│  ├─ Doctor.java        ├─ Billing.java                  │
│  ├─ Bed.java           ├─ Prescription.java             │
│  │                     └─ User.java                     │
│                                                         │
│  Represents: Hospital entities & their properties       │
└─────────────────────────────────────────────────────────┘
                            ▲
                            │
                   (Stores in collections)
                            │
┌─────────────────────────────────────────────────────────┐
│               IN-MEMORY DATA STORAGE LAYER              │
│                                                         │
│  Java Collections:                                      │
│  ├─ ArrayList<Patient>                                  │
│  ├─ ArrayList<Doctor>                                   │
│  ├─ ArrayList<Bed>                                      │
│  ├─ ArrayList<Appointment>                              │
│  ├─ ArrayList<Billing>                                  │
│  ├─ ArrayList<Prescription>                             │
│  └─ ArrayList<User>                                     │
│                                                         │
│  Note: ⚠️ Data lost on program end (RAM-based)         │
└─────────────────────────────────────────────────────────┘

Future Layer (Not implemented yet):
┌─────────────────────────────────────────────────────────┐
│            DATABASE LAYER (PostgreSQL)                  │
│                                                         │
│  Will include:                                          │
│  ├─ 13 Tables (patients, doctors, beds, etc.)          │
│  ├─ Foreign Key Relationships                           │
│  ├─ Indexes for Performance                             │
│  └─ Views for Reporting                                 │
│                                                         │
│  Status: ❌ Not yet connected (schema exists)           │
└─────────────────────────────────────────────────────────┘
```

---

This visual guide shows exactly how the Apollo Hospital ERP System is structured and how data flows through it!


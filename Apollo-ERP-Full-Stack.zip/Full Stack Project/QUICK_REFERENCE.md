# 🎯 APOLLO HOSPITAL ERP - QUICK REFERENCE CARD

## **SIMPLEST WAY TO RUN (Copy & Paste)**

### Option A: Command Prompt (Fastest ⚡)
```bash
cd C:\Users\subha\eclipse-workspace\Full Stack Project && java -cp bin ERP.ApolloHospital
```

### Option B: Eclipse IDE (Easiest ✅)
1. Open Eclipse
2. File → Open Projects from File System
3. Select: `C:\Users\subha\eclipse-workspace\Full Stack Project`
4. Right-click: `src → ERP → ApolloHospital.java`
5. Select: `Run As → Java Application`

---

## **WHAT HAPPENS WHEN YOU RUN IT**

| Step | What Runs | Output |
|------|-----------|--------|
| 1 | Welcome Banner | Hospital ERP System v1.0 |
| 2 | Patient Registration | Patient "Vikram Singh" created (ID: 1001) |
| 3 | Appointment Booking | Appointment #5001 with Dr. Rajesh |
| 4 | Bed Admission | Patient admitted to ICU-101 |
| 5 | Billing | Invoice #2001 for ₹25,500 created |
| 6 | Statistics | Shows 1 patient, 3 doctors, 7 beds |
| 7 | Doctor List | Lists all available doctors |
| 8 | Bed Report | Shows bed occupancy per ward |
| 9 | Financial Summary | Revenue and pending invoices |
| 10 | Success Message | Demo completed successfully |

**Duration:** 2-3 seconds ⏱️

---

## **FOLDER STRUCTURE (FIND FILES HERE)**

```
C:\Users\subha\eclipse-workspace\Full Stack Project\
│
├── src\ (Source Code)
│   └── ERP\
│       ├── ApolloHospital.java ★★★ RUN THIS
│       ├── HospitalManagementSystem.java
│       ├── models\ (7 classes)
│       │   ├── Patient.java
│       │   ├── Doctor.java
│       │   ├── Bed.java
│       │   ├── Appointment.java
│       │   ├── Billing.java
│       │   ├── Prescription.java
│       │   └── User.java
│       └── services\ (4 classes)
│           ├── PatientService.java
│           ├── BedService.java
│           ├── AppointmentService.java
│           └── BillingService.java
│
├── bin\ (Compiled Files - Auto-generated)
│   └── ERP\
│       └── *.class files
│
└── *.md files (Documentation)
    ├── README.md
    ├── QUICK_START.md ✅ Read this first
    ├── HOW_TO_RUN.md
    ├── VISUAL_GUIDE.md
    ├── COMPLETION_SUMMARY.md
    └── hospital_schema.sql (Database schema)
```

---

## **KEY CLASSES EXPLAINED**

### 🎯 **ApolloHospital.java** (ENTRY POINT)
- **Location:** `src/ERP/ApolloHospital.java`
- **Purpose:** Main class - starts the program
- **Contains:** `main()` method and demo functions
- **To Run:** Right-click → Run As → Java Application

### 🏥 **HospitalManagementSystem.java** (COORDINATOR)
- **Location:** `src/ERP/HospitalManagementSystem.java`
- **Purpose:** Central orchestrator - manages everything
- **Contains:** Methods for all hospital operations
- **Used By:** ApolloHospital.java

### 👤 **Data Models** (Entity Classes)
- **Patient.java** - Patient information
- **Doctor.java** - Doctor details & specialization
- **Bed.java** - Bed & ward management
- **Appointment.java** - Appointment scheduling
- **Billing.java** - Invoice & charges
- **Prescription.java** - Medicine tracking
- **User.java** - User accounts (Admin, Doctor, Patient)

### ⚙️ **Services** (Business Logic)
- **PatientService.java** - Handles patient operations
- **BedService.java** - Handles bed operations
- **AppointmentService.java** - Handles appointment operations
- **BillingService.java** - Handles billing operations

---

## **TROUBLESHOOTING QUICK FIX**

| Error | Fix |
|-------|-----|
| "Cannot find symbol" or compile errors | Right-click project → Build Project (Ctrl+B) |
| "java: command not found" | Install Java from oracle.com |
| Program doesn't output anything | Click Console tab in Eclipse |
| File not found error | Check path is: `C:\Users\subha\eclipse-workspace\Full Stack Project` |
| "ApolloHospital.class" not found | The bin folder exists, recompile with Ctrl+B |

---

## **SYSTEM CAPABILITIES CHECKLIST**

✅ **Features Working in Demo:**
- [x] Patient registration with full details
- [x] Doctor management & specialization lookup
- [x] Appointment booking with date/time
- [x] Hospital bed allocation & tracking
- [x] Automatic billing & invoice generation
- [x] Real-time system statistics
- [x] Bed occupancy reports by ward
- [x] Financial summary & analytics

❌ **Not Yet Implemented:**
- [ ] Database persistence (data stored in memory only)
- [ ] Web API (REST endpoints)
- [ ] User interface (web/mobile)
- [ ] User authentication/login
- [ ] Payment processing
- [ ] Email notifications

---

## **SAMPLE OUTPUT YOU'LL SEE**

```
╔════════════════════════════════════════════════════════╗
║    APOLLO HOSPITAL MANAGEMENT ERP SYSTEM v1.0         ║
╚════════════════════════════════════════════════════════╝

✓ Patient Registered: Vikram Singh (ID: 1001)
✓ Appointment Booked: #5001 with Dr. Rajesh (Cardiology)
✓ Patient Admitted: ICU-101 bed (₹5000/day)
✓ Invoice Created: #2001 (Total: ₹25,500)

========== SYSTEM STATUS ==========
Total Active Patients: 1
Total Registered Doctors: 3
Available Beds: 7 (ICU: 2, General: 3, Emergency: 2)
Pending Invoices: 1

╔════════════════════════════════════════════════════════╗
║  DEMO COMPLETED SUCCESSFULLY                          ║
╚════════════════════════════════════════════════════════╝
```

---

## **DEVELOPER REFERENCE**

### Main Methods in HospitalManagementSystem.java:
```
registerNewPatient()        → Create new patient
bookAppointment()           → Schedule appointment
admitPatientToBed()        → Assign bed to patient
createInvoice()            → Generate billing invoice
addBedCharges()            → Add bed costs
addConsultationCharges()   → Add doctor fees
getAvailableBeds()         → Get free beds
getDoctorsBySpecialization() → Find doctors
getSystemStatistics()      → Get dashboard data
displaySystemStatus()      → Print statistics
getBedOccupancy()          → Get occupancy report
getTotalRevenue()          → Get financial data
```

### Service Classes:
```
PatientService        → Patient CRUD operations
BedService           → Bed allocation & occupancy
AppointmentService   → Appointment management
BillingService       → Invoice & charge management
```

---

## **RUN IT MULTIPLE TIMES**

Each run creates fresh data:
```bash
# Run 1st time
java -cp bin ERP.ApolloHospital

# Wait for it to finish...

# Run 2nd time (starts fresh)
java -cp bin ERP.ApolloHospital

# Each run shows new patient registration
```

---

## **FILE LOCATIONS QUICK MAP**

| What | Where |
|-----|-------|
| Source code | `src\ERP\` |
| Main class | `src\ERP\ApolloHospital.java` |
| Run compiled | `bin\ERP\ApolloHospital.class` |
| Models | `src\ERP\models\` |
| Services | `src\ERP\services\` |
| Docs | `\` (root folder) |
| Database schema | `hospital_schema.sql` |

---

## **NEXT STEPS (OPTIONAL)**

After running the demo, you can:

1. **Modify Code** - Change patient names, doctor fees, etc.
   - Edit any .java file in `src/ERP/`
   - Save and rebuild (`Ctrl+B`)
   - Run again

2. **Add Features** - Extend the system
   - Add new services
   - Add new models
   - Modify business logic

3. **Database Integration** - Store data permanently
   - Set up PostgreSQL
   - Use JPA/Hibernate
   - Configure connection

4. **Web Interface** - Make it accessible online
   - Add Spring Boot
   - Create REST API
   - Build React frontend

---

## **QUICK COMMANDS**

| Task | Command |
|------|---------|
| Compile | `javac -d bin src/ERP/*.java src/ERP/models/*.java src/ERP/services/*.java` |
| Run | `java -cp bin ERP.ApolloHospital` |
| Check Java | `java -version` |
| View folder | `dir "C:\Users\subha\eclipse-workspace\Full Stack Project"` |

---

## **SYSTEM REQUIREMENTS**

✅ **What You Need:**
- Java 8 or higher installed
- Eclipse IDE (optional but recommended)
- Command Prompt or PowerShell
- 100MB free disk space

✅ **What's Included:**
- Complete source code
- Compiled .class files (ready to run)
- Documentation
- Database schema

❌ **What You Don't Need:**
- PostgreSQL (not connected yet)
- Spring Boot (not integrated)
- Node.js (no frontend yet)
- Docker (deployment ready)

---

## **SUPPORT RESOURCES**

| Question | Answer |
|----------|--------|
| How to run? | See "HOW_TO_RUN.md" |
| How does it work? | See "VISUAL_GUIDE.md" |
| What features? | See "README.md" or "COMPLETION_SUMMARY.md" |
| What's implemented? | See "PROJECT_DOCUMENTATION.md" |
| How to extend? | See "IMPLEMENTATION_GUIDE.md" |

---

## **CHEAT SHEET - FASTEST EXECUTION**

**Windows Command Prompt:**
```
cd C:\Users\subha\eclipse-workspace\Full Stack Project
java -cp bin ERP.ApolloHospital
```

**That's it! You'll see the demo output in 2-3 seconds.** ⚡

---

**Status:** ✅ Ready to Run  
**Last Updated:** December 12, 2025  
**Project Version:** 1.0


# ⚡ GITHUB UPLOAD - QUICK START (5 MINUTES)

---

## **👤 YOUR GITHUB ACCOUNT**

```
Username: subhajeet-patra94
Email: subhajeetp@outlook.com
```

---

## **🎯 DO THIS NOW**

### **Step 1: Create Repository (1 min)**
- Go to: https://github.com/new
- Name: Apollo-Hospital-ERP
- Create it

### **Step 2: Run Upload Script (2-3 min)**
- Open File Explorer
- Find: GITHUB_UPLOAD_NOW.bat
- Double-click it
- Done!

---

## **🌐 YOUR REPOSITORY**

```
https://github.com/subhajeet-patra94/Apollo-Hospital-ERP
```

---

## **✅ COMPLETE!**

Apollo Hospital ERP System is on GitHub! 🎉


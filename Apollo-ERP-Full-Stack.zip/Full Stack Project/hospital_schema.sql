-- ============================================
-- APOLLO HOSPITAL MANAGEMENT SYSTEM
-- PostgreSQL Database Schema
-- Version 1.0
-- ============================================

-- Create Database
-- CREATE DATABASE apollo_hospital;
-- \c apollo_hospital;

-- ============================================
-- Users Table (Admin, Doctor, Patient, Staff)
-- ============================================
CREATE TABLE users (
    user_id SERIAL PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    role VARCHAR(20) NOT NULL CHECK (role IN ('Admin', 'Doctor', 'Patient', 'Staff')),
    department VARCHAR(100),
    status VARCHAR(20) DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive', 'Suspended')),
    two_factor_enabled BOOLEAN DEFAULT FALSE,
    last_login TIMESTAMP,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    modified_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- Patients Table
-- ============================================
CREATE TABLE patients (
    patient_id SERIAL PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20) NOT NULL,
    date_of_birth DATE NOT NULL,
    gender VARCHAR(10) CHECK (gender IN ('Male', 'Female', 'Other')),
    address VARCHAR(255),
    blood_group VARCHAR(5) CHECK (blood_group IN ('A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-')),
    emergency_contact VARCHAR(20),
    medical_history TEXT,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'Active' CHECK (status IN ('Active', 'Discharged', 'Inactive'))
);

-- ============================================
-- Doctors Table
-- ============================================
CREATE TABLE doctors (
    doctor_id SERIAL PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20),
    specialization VARCHAR(100) NOT NULL,
    qualifications VARCHAR(200),
    license_number VARCHAR(50) NOT NULL UNIQUE,
    department VARCHAR(100),
    availability_status VARCHAR(20) DEFAULT 'Available' CHECK (availability_status IN ('Available', 'Unavailable', 'OnLeave')),
    office_hours VARCHAR(100),
    years_of_experience INT,
    consultation_fee DECIMAL(10, 2),
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- Beds & Ward Table
-- ============================================
CREATE TABLE beds (
    bed_id SERIAL PRIMARY KEY,
    ward_name VARCHAR(100) NOT NULL,
    bed_type VARCHAR(50) NOT NULL CHECK (bed_type IN ('ICU', 'General', 'Emergency', 'Maternity')),
    bed_number VARCHAR(20) NOT NULL UNIQUE,
    floor INT,
    status VARCHAR(20) DEFAULT 'Available' CHECK (status IN ('Available', 'Occupied', 'Maintenance')),
    patient_id INT,
    daily_rate DECIMAL(10, 2),
    equipment VARCHAR(200),
    admission_date DATE,
    expected_discharge_date DATE,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id)
);

-- ============================================
-- Appointments Table
-- ============================================
CREATE TABLE appointments (
    appointment_id SERIAL PRIMARY KEY,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    status VARCHAR(20) DEFAULT 'Scheduled' CHECK (status IN ('Scheduled', 'Completed', 'Cancelled', 'NoShow')),
    notes TEXT,
    department VARCHAR(100),
    consultation_type VARCHAR(50) DEFAULT 'In-person' CHECK (consultation_type IN ('In-person', 'Telemedicine')),
    consultation_fee DECIMAL(10, 2),
    reminder_sent VARCHAR(100),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
    FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id)
);

-- ============================================
-- Prescriptions Table
-- ============================================
CREATE TABLE prescriptions (
    prescription_id SERIAL PRIMARY KEY,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    medicine_name VARCHAR(255) NOT NULL,
    dosage VARCHAR(100),
    frequency VARCHAR(100),
    duration VARCHAR(100),
    prescription_date DATE DEFAULT CURRENT_DATE,
    notes TEXT,
    status VARCHAR(20) DEFAULT 'Active' CHECK (status IN ('Active', 'Completed', 'Cancelled')),
    expiry_date DATE,
    refill_allowed BOOLEAN DEFAULT TRUE,
    refill_count INT DEFAULT 0,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
    FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id)
);

-- ============================================
-- Billing & Invoices Table
-- ============================================
CREATE TABLE billing (
    invoice_id SERIAL PRIMARY KEY,
    patient_id INT NOT NULL,
    bed_id INT,
    invoice_date DATE DEFAULT CURRENT_DATE,
    admission_date DATE,
    discharge_date DATE,
    bed_charges DECIMAL(12, 2) DEFAULT 0,
    consultation_charges DECIMAL(12, 2) DEFAULT 0,
    medicine_charges DECIMAL(12, 2) DEFAULT 0,
    lab_charges DECIMAL(12, 2) DEFAULT 0,
    other_charges DECIMAL(12, 2) DEFAULT 0,
    total_amount DECIMAL(12, 2),
    amount_paid DECIMAL(12, 2) DEFAULT 0,
    pending_amount DECIMAL(12, 2),
    payment_status VARCHAR(20) DEFAULT 'Pending' CHECK (payment_status IN ('Pending', 'Partial', 'Paid')),
    payment_method VARCHAR(50) CHECK (payment_method IN ('Cash', 'Card', 'Insurance', 'Online', 'Cheque')),
    insurance_provider VARCHAR(100),
    insurance_policy_number VARCHAR(100),
    insured_amount DECIMAL(12, 2),
    notes TEXT,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
    FOREIGN KEY (bed_id) REFERENCES beds(bed_id)
);

-- ============================================
-- Billing Details Table (Individual Charges)
-- ============================================
CREATE TABLE billing_details (
    billing_detail_id SERIAL PRIMARY KEY,
    invoice_id INT NOT NULL,
    charge_type VARCHAR(100) NOT NULL,
    charge_description VARCHAR(255),
    amount DECIMAL(10, 2) NOT NULL,
    charge_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (invoice_id) REFERENCES billing(invoice_id)
);

-- ============================================
-- Lab Tests Table
-- ============================================
CREATE TABLE lab_tests (
    test_id SERIAL PRIMARY KEY,
    patient_id INT NOT NULL,
    test_name VARCHAR(255) NOT NULL,
    test_date DATE DEFAULT CURRENT_DATE,
    results TEXT,
    test_status VARCHAR(20) DEFAULT 'Pending' CHECK (test_status IN ('Pending', 'Completed', 'Cancelled')),
    cost DECIMAL(10, 2),
    doctor_id INT,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
    FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id)
);

-- ============================================
-- Inventory Management Table
-- ============================================
CREATE TABLE inventory (
    inventory_id SERIAL PRIMARY KEY,
    item_name VARCHAR(255) NOT NULL,
    item_type VARCHAR(50),
    quantity INT,
    minimum_stock INT,
    unit_price DECIMAL(10, 2),
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- Indexes for Performance Optimization
-- ============================================

-- Patients Index
CREATE INDEX idx_patient_name ON patients(first_name, last_name);
CREATE INDEX idx_patient_email ON patients(email);
CREATE INDEX idx_patient_status ON patients(status);

-- Doctors Index
CREATE INDEX idx_doctor_specialization ON doctors(specialization);
CREATE INDEX idx_doctor_availability ON doctors(availability_status);
CREATE INDEX idx_doctor_department ON doctors(department);

-- Beds Index
CREATE INDEX idx_bed_status ON beds(status);
CREATE INDEX idx_bed_type ON beds(bed_type);
CREATE INDEX idx_bed_ward ON beds(ward_name);

-- Appointments Index
CREATE INDEX idx_appointment_patient ON appointments(patient_id);
CREATE INDEX idx_appointment_doctor ON appointments(doctor_id);
CREATE INDEX idx_appointment_date ON appointments(appointment_date);
CREATE INDEX idx_appointment_status ON appointments(status);

-- Billing Index
CREATE INDEX idx_billing_patient ON billing(patient_id);
CREATE INDEX idx_billing_status ON billing(payment_status);
CREATE INDEX idx_billing_invoice_date ON billing(invoice_date);

-- ============================================
-- Views for Reporting
-- ============================================

-- Active Patients View
CREATE VIEW active_patients AS
SELECT * FROM patients
WHERE status = 'Active';

-- Available Doctors View
CREATE VIEW available_doctors AS
SELECT * FROM doctors
WHERE availability_status = 'Available';

-- Available Beds View
CREATE VIEW available_beds AS
SELECT * FROM beds
WHERE status = 'Available';

-- Pending Invoices View
CREATE VIEW pending_invoices AS
SELECT * FROM billing
WHERE payment_status IN ('Pending', 'Partial');

-- Doctor Appointment Schedule View
CREATE VIEW doctor_appointments AS
SELECT 
    a.appointment_id,
    a.appointment_date,
    a.appointment_time,
    d.first_name,
    d.last_name,
    p.first_name AS patient_first_name,
    p.last_name AS patient_last_name,
    a.status
FROM appointments a
JOIN doctors d ON a.doctor_id = d.doctor_id
JOIN patients p ON a.patient_id = p.patient_id
ORDER BY a.appointment_date, a.appointment_time;

-- Revenue Report View
CREATE VIEW revenue_report AS
SELECT 
    DATE_TRUNC('month', invoice_date)::DATE AS month,
    COUNT(*) AS total_invoices,
    SUM(total_amount) AS total_revenue,
    SUM(amount_paid) AS amount_collected,
    SUM(pending_amount) AS outstanding_amount
FROM billing
GROUP BY DATE_TRUNC('month', invoice_date);

-- ============================================
-- Sample Data Insertion (Optional)
-- ============================================

-- Insert Admin User
INSERT INTO users (username, password, email, first_name, last_name, role, status)
VALUES ('admin', 'admin@123', 'admin@hospital.com', 'System', 'Administrator', 'Admin', 'Active');

-- Insert Sample Doctors
INSERT INTO doctors (first_name, last_name, email, phone, specialization, license_number, department, consultation_fee)
VALUES 
('Rajesh', 'Kumar', 'rajesh@hospital.com', '9876543210', 'Cardiology', 'LIC-001', 'Cardiology', 500.00),
('Priya', 'Sharma', 'priya@hospital.com', '9876543211', 'Pediatrics', 'LIC-002', 'Pediatrics', 400.00),
('Anil', 'Verma', 'anil@hospital.com', '9876543212', 'Surgery', 'LIC-003', 'Surgery', 600.00);

-- Insert Sample Beds
INSERT INTO beds (ward_name, bed_type, bed_number, floor, daily_rate)
VALUES 
('ICU', 'ICU', 'ICU-101', 1, 5000.00),
('ICU', 'ICU', 'ICU-102', 1, 5000.00),
('General Ward', 'General', 'GW-201', 2, 1500.00),
('Emergency', 'Emergency', 'EM-301', 3, 3000.00);

-- ============================================
-- End of Schema
-- ============================================

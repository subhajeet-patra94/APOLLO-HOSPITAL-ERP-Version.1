# 📤 UPLOAD TO GITHUB - VISUAL QUICK GUIDE

## **3 SIMPLE STEPS**

---

## **STEP 1️⃣: CREATE GITHUB REPO (2 minutes)**

```
1. Go to: https://github.com/new
   
2. Fill in:
   - Repository name: Apollo-Hospital-ERP
   - Description: Apollo Hospital Management ERP System
   
3. Click: "Create repository"
   
4. COPY THIS URL: https://github.com/YOUR-USERNAME/Apollo-Hospital-ERP.git
   (It will be different for you - use YOUR GitHub username)
```

---

## **STEP 2️⃣: OPEN COMMAND PROMPT (1 minute)**

```
Windows Key + R
  ↓
Type: cmd
  ↓
Press: Enter
```

---

## **STEP 3️⃣: RUN THESE COMMANDS (2 minutes)**

### **Copy each command and paste into Command Prompt:**

#### **Command 1:**
```bash
cd "C:\Users\subha\eclipse-workspace\Full Stack Project"
```
Press Enter

#### **Command 2:**
```bash
git init
```
Press Enter

#### **Command 3:**
```bash
git remote add origin https://github.com/YOUR-USERNAME/Apollo-Hospital-ERP.git
```
⚠️ **REPLACE YOUR-USERNAME with your actual GitHub username**

Press Enter

#### **Command 4:**
```bash
git branch -M main
```
Press Enter

#### **Command 5:**
```bash
git add .
```
Press Enter

#### **Command 6:**
```bash
git commit -m "Initial commit: Apollo Hospital ERP System v1.0"
```
Press Enter

#### **Command 7:**
```bash
git push -u origin main
```
Press Enter

**When asked for password: Use your GitHub Personal Access Token (see next section)**

---

## **🔑 IF PASSWORD FAILS - GET TOKEN**

1. Go to: https://github.com/settings/tokens
2. Click: "Generate new token" → "Generate new token (classic)"
3. Name: `git-upload`
4. Check: ✅ repo
5. Click: "Generate token"
6. **COPY THE TOKEN** (appears only once!)
7. Use this token when prompted for password

---

## **✅ SUCCESS INDICATORS**

When done correctly, you'll see:
```
Enumerating objects: 150+
Counting objects: 100%
Writing objects: 100%
[new branch]      main -> main
Branch 'main' set up to track remote branch 'main' from 'origin'.
```

---

## **🎊 VERIFY UPLOAD**

After upload:
1. Open browser
2. Go to: `https://github.com/YOUR-USERNAME/Apollo-Hospital-ERP`
3. You should see all your files! ✅

---

## **⏱️ TOTAL TIME: 5 MINUTES**

- Create repo: 2 min
- Open cmd: 1 min
- Run commands: 2 min
- **Done!** 🚀

---

## **📋 ONE-COMMAND CHEAT SHEET**

If you want, here's almost everything in ONE place to copy-paste:

```bash
cd "C:\Users\subha\eclipse-workspace\Full Stack Project" && git init && git remote add origin https://github.com/YOUR-USERNAME/Apollo-Hospital-ERP.git && git branch -M main && git add . && git commit -m "Initial commit: Apollo Hospital ERP System v1.0" && git push -u origin main
```

⚠️ **Replace YOUR-USERNAME first!**

---

## **🆘 QUICK FIXES**

| Problem | Solution |
|---------|----------|
| "git: command not found" | Install Git from git-scm.com |
| "fatal: destination path already exists" | Run: `rm -r .git` then `git init` |
| "authentication failed" | Use Personal Access Token, not password |
| Nothing happens | Press Enter again, check network |

---

**That's it! Your project is now on GitHub!** 🎉


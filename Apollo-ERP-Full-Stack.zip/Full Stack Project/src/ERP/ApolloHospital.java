package ERP;

import ERP.models.*;
import java.util.*;

/**
 * ApolloHospital - Hospital Management System Entry Point
 * This is the main class for demonstrating the Apollo Hospital ERP System
 * 
 * Features:
 * - Patient Management
 * - Doctor & Staff Management
 * - Bed & Ward Management
 * - Appointment Scheduling
 * - Billing & Invoice Management
 * - Admin Dashboard with Analytics
 */
public class ApolloHospital {

	private HospitalManagementSystem hms;

	public ApolloHospital() {
		this.hms = new HospitalManagementSystem();
	}

	public static void main(String[] args) {
		ApolloHospital hospital = new ApolloHospital();
		hospital.displayWelcomeMessage();
		hospital.demonstrateSystem();
	}
	
	/**
	 * Display welcome message for the hospital system
	 */
	public void displayWelcomeMessage() {
		System.out.println("\n╔════════════════════════════════════════════════════════╗");
		System.out.println("║    APOLLO HOSPITAL MANAGEMENT ERP SYSTEM v1.0         ║");
		System.out.println("║    Full Stack Hospital Management Solution           ║");
		System.out.println("╚════════════════════════════════════════════════════════╝\n");
		System.out.println("Welcome to Apollo Hospital Management System");
		System.out.println("Integrated Patient, Bed, Doctor & Billing Modules");
		System.out.println("Tech Stack: Java Backend | React Frontend | PostgreSQL\n");
	}

	/**
	 * Demonstrate the complete system functionality
	 */
	private void demonstrateSystem() {
		System.out.println("========== DEMO: Registering New Patient ==========");
		// Register a new patient
		Patient patient1 = hms.registerNewPatient("Vikram", "Singh", "vikram@email.com",
				"9876543210", "1985-05-15", "Male", "123 Street Road, City", "O+", "9876543220");
		System.out.println("✓ Patient Registered: " + patient1);

		System.out.println("\n========== DEMO: Booking Appointment ==========");
		// Get available doctors
		List<Doctor> cardiologists = hms.getDoctorsBySpecialization("Cardiology");
		if (!cardiologists.isEmpty()) {
			Doctor doctor = cardiologists.get(0);
			Appointment appointment = hms.bookAppointment(patient1.getPatientId(), 
					doctor.getDoctorId(), "2025-12-15", "10:00 AM", "Cardiology");
			System.out.println("✓ Appointment Booked: " + appointment);
			System.out.println("  Doctor: " + doctor.getFirstName() + " " + doctor.getLastName());
			System.out.println("  Consultation Fee: ₹" + doctor.getConsultationFee());
		}

		System.out.println("\n========== DEMO: Admitting Patient to Bed ==========");
		// Get available ICU bed
		List<Bed> icuBeds = hms.getAvailableBeds("ICU");
		if (!icuBeds.isEmpty()) {
			Bed bed = icuBeds.get(0);
			boolean admitted = hms.admitPatientToBed(bed.getBedId(), patient1.getPatientId(),
					java.time.LocalDate.now().toString(), "2025-12-20");
			if (admitted) {
				System.out.println("✓ Patient Admitted to Bed: " + bed.getBedNumber());
				System.out.println("  Ward: " + bed.getWardName());
				System.out.println("  Daily Rate: ₹" + bed.getDailyRate());
			}
		}

		System.out.println("\n========== DEMO: Creating Billing Invoice ==========");
		// Create billing invoice
		Billing invoice = hms.createInvoice(patient1.getPatientId(), 1, 
				java.time.LocalDate.now().toString(), "2025-12-20");
		System.out.println("✓ Invoice Created: #" + invoice.getInvoiceId());
		
		// Add charges
		hms.addBedCharges(invoice.getInvoiceId(), 5, 5000);
		hms.addConsultationCharges(invoice.getInvoiceId(), 500);
		System.out.println("✓ Charges Added - Bed (5 days @ ₹5000): ₹25000");
		System.out.println("✓ Charges Added - Consultation: ₹500");
		System.out.println("  Total Invoice Amount: ₹" + (25000 + 500));

		System.out.println("\n========== DEMO: System Statistics ==========");
		// Display system statistics
		hms.displaySystemStatus();

		System.out.println("========== DEMO: Available Doctors ==========");
		// Display available doctors
		List<Doctor> allDoctors = hms.getAllDoctors();
		for (Doctor doc : allDoctors) {
			System.out.println("✓ " + doc.getFirstName() + " " + doc.getLastName() + 
					" | Specialization: " + doc.getSpecialization() + 
					" | Status: " + doc.getAvailabilityStatus() +
					" | Consultation: ₹" + doc.getConsultationFee());
		}

		System.out.println("\n========== DEMO: Bed Occupancy Report ==========");
		// Display bed occupancy
		Map<String, Integer> occupancy = hms.getBedOccupancy();
		for (String ward : occupancy.keySet()) {
			System.out.println("✓ " + ward + ": " + occupancy.get(ward) + " beds occupied");
		}

		System.out.println("\n========== DEMO: Financial Summary ==========");
		System.out.println("✓ Total Revenue: ₹" + hms.getTotalRevenue());
		System.out.println("✓ Outstanding Amount: ₹" + hms.getTotalOutstanding());
		System.out.println("✓ Pending Invoices: " + hms.getPendingInvoices().size());

		System.out.println("\n╔════════════════════════════════════════════════════════╗");
		System.out.println("║  DEMO COMPLETED SUCCESSFULLY                          ║");
		System.out.println("║  System is ready for full-scale deployment            ║");
		System.out.println("╚════════════════════════════════════════════════════════╝\n");
	}
}

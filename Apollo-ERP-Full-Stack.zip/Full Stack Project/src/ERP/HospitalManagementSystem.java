package ERP;

import ERP.models.*;
import ERP.services.*;
import java.util.*;

/**
 * HospitalManagementSystem - Main system that coordinates all modules
 * Integrates Patient, Doctor, Bed, Appointment, and Billing management
 */
public class HospitalManagementSystem {
    private PatientService patientService;
    private BedService bedService;
    private AppointmentService appointmentService;
    private BillingService billingService;
    private List<Doctor> doctors;
    private List<User> users;
    private int doctorIdCounter;
    private int userIdCounter;

    public HospitalManagementSystem() {
        this.patientService = new PatientService();
        this.bedService = new BedService();
        this.appointmentService = new AppointmentService();
        this.billingService = new BillingService();
        this.doctors = new ArrayList<>();
        this.users = new ArrayList<>();
        this.doctorIdCounter = 3001;
        this.userIdCounter = 4001;
        initializeSystemData();
    }

    /**
     * Initialize sample data for demonstration
     */
    private void initializeSystemData() {
        // Initialize beds
        initializeBeds();
        // Initialize sample doctors
        initializeDoctors();
        // Initialize sample admin user
        initializeAdminUser();
    }

    /**
     * Initialize beds in different wards
     */
    private void initializeBeds() {
        // ICU Beds
        bedService.addBed("ICU", "ICU", "ICU-101", "1", 5000.0);
        bedService.addBed("ICU", "ICU", "ICU-102", "1", 5000.0);
        bedService.addBed("ICU", "ICU", "ICU-103", "1", 5000.0);

        // General Ward Beds
        bedService.addBed("General Ward", "General", "GW-201", "2", 1500.0);
        bedService.addBed("General Ward", "General", "GW-202", "2", 1500.0);
        bedService.addBed("General Ward", "General", "GW-203", "2", 1500.0);

        // Emergency Beds
        bedService.addBed("Emergency", "Emergency", "EM-301", "3", 3000.0);
        bedService.addBed("Emergency", "Emergency", "EM-302", "3", 3000.0);

        // Maternity Beds
        bedService.addBed("Maternity", "Maternity", "MT-401", "4", 2500.0);
        bedService.addBed("Maternity", "Maternity", "MT-402", "4", 2500.0);
    }

    /**
     * Initialize sample doctors
     */
    private void initializeDoctors() {
        Doctor doc1 = new Doctor(doctorIdCounter++, "Rajesh", "Kumar", "rajesh@hospital.com", 
                                "9876543210", "Cardiology", "Cardiology", "LIC-001", 15);
        doc1.setConsultationFee(500.0);
        doc1.setQualifications("MBBS, MD");
        doc1.setRegistrationDate(java.time.LocalDate.now().toString());
        doctors.add(doc1);

        Doctor doc2 = new Doctor(doctorIdCounter++, "Priya", "Sharma", "priya@hospital.com", 
                                "9876543211", "Pediatrics", "Pediatrics", "LIC-002", 10);
        doc2.setConsultationFee(400.0);
        doc2.setQualifications("MBBS, MD");
        doc2.setRegistrationDate(java.time.LocalDate.now().toString());
        doctors.add(doc2);

        Doctor doc3 = new Doctor(doctorIdCounter++, "Anil", "Verma", "anil@hospital.com", 
                                "9876543212", "Surgery", "Surgery", "LIC-003", 20);
        doc3.setConsultationFee(600.0);
        doc3.setQualifications("MBBS, MS");
        doc3.setRegistrationDate(java.time.LocalDate.now().toString());
        doctors.add(doc3);
    }

    /**
     * Initialize admin user
     */
    private void initializeAdminUser() {
        User admin = new User(userIdCounter++, "admin", "admin123", "admin@hospital.com", 
                             "System", "Administrator", "Admin");
        admin.setRegistrationDate(java.time.LocalDate.now().toString());
        users.add(admin);
    }

    // ==================== Patient Management ====================

    public Patient registerNewPatient(String firstName, String lastName, String email, 
                                     String phone, String dateOfBirth, String gender, 
                                     String address, String bloodGroup, String emergencyContact) {
        return patientService.registerPatient(firstName, lastName, email, phone, 
                                             dateOfBirth, gender, address, bloodGroup, emergencyContact);
    }

    public Patient getPatient(int patientId) {
        return patientService.getPatientById(patientId);
    }

    public List<Patient> searchPatients(String name) {
        return patientService.searchPatientsByName(name);
    }

    public List<Patient> getAllPatients() {
        return patientService.getAllPatients();
    }

    public boolean dischargePatient(int patientId) {
        return patientService.dischargePatient(patientId);
    }

    // ==================== Doctor Management ====================

    public Doctor getDoctor(int doctorId) {
        for (Doctor doctor : doctors) {
            if (doctor.getDoctorId() == doctorId) {
                return doctor;
            }
        }
        return null;
    }

    public List<Doctor> getAllDoctors() {
        return new ArrayList<>(doctors);
    }

    public List<Doctor> getDoctorsBySpecialization(String specialization) {
        List<Doctor> result = new ArrayList<>();
        for (Doctor doctor : doctors) {
            if (specialization.equalsIgnoreCase(doctor.getSpecialization())) {
                result.add(doctor);
            }
        }
        return result;
    }

    public List<Doctor> getAvailableDoctors() {
        List<Doctor> available = new ArrayList<>();
        for (Doctor doctor : doctors) {
            if ("Available".equalsIgnoreCase(doctor.getAvailabilityStatus())) {
                available.add(doctor);
            }
        }
        return available;
    }

    public boolean updateDoctorAvailability(int doctorId, String status) {
        Doctor doctor = getDoctor(doctorId);
        if (doctor != null) {
            doctor.setAvailabilityStatus(status);
            return true;
        }
        return false;
    }

    // ==================== Bed Management ====================

    public List<Bed> getAvailableBeds(String bedType) {
        return bedService.getAvailableBedsByType(bedType);
    }

    public int getAvailableBedCount(String bedType) {
        return bedService.getAvailableBedCountByType(bedType);
    }

    public boolean admitPatientToBed(int bedId, int patientId, String admissionDate, String expectedDischargeDate) {
        return bedService.occupyBed(bedId, patientId, admissionDate, expectedDischargeDate);
    }

    public boolean dischargePatientFromBed(int patientId) {
        return bedService.dischargeBedByPatient(patientId);
    }

    public Map<String, Integer> getBedOccupancy() {
        return bedService.getOccupancyByWard();
    }

    public double getBedOccupancyPercentage(String bedType) {
        return bedService.getOccupancyPercentageByType(bedType);
    }

    public boolean isICUFull() {
        return bedService.isICUFull();
    }

    public boolean isEmergencyFull() {
        return bedService.isEmergencyBedsFull();
    }

    // ==================== Appointment Management ====================

    public Appointment bookAppointment(int patientId, int doctorId, String appointmentDate, 
                                       String appointmentTime, String department) {
        return appointmentService.bookAppointment(patientId, doctorId, appointmentDate, appointmentTime, department);
    }

    public boolean rescheduleAppointment(int appointmentId, String newDate, String newTime) {
        return appointmentService.rescheduleAppointment(appointmentId, newDate, newTime);
    }

    public boolean cancelAppointment(int appointmentId) {
        return appointmentService.cancelAppointment(appointmentId);
    }

    public List<Appointment> getPatientAppointments(int patientId) {
        return appointmentService.getAppointmentsByPatientId(patientId);
    }

    public List<Appointment> getDoctorAppointments(int doctorId) {
        return appointmentService.getAppointmentsByDoctorId(doctorId);
    }

    public int getTotalAppointments() {
        return appointmentService.getTotalAppointmentCount();
    }

    public int getCompletedAppointments() {
        return appointmentService.getCompletedAppointmentCount();
    }

    // ==================== Billing Management ====================

    public Billing createInvoice(int patientId, int bedId, String admissionDate, String dischargeDate) {
        return billingService.createInvoice(patientId, bedId, admissionDate, dischargeDate);
    }

    public Billing getInvoice(int invoiceId) {
        return billingService.getInvoiceById(invoiceId);
    }

    public List<Billing> getPatientInvoices(int patientId) {
        return billingService.getInvoicesByPatientId(patientId);
    }

    public void addBedCharges(int invoiceId, int numberOfDays, double dailyRate) {
        billingService.addBedCharges(invoiceId, numberOfDays, dailyRate);
    }

    public void addConsultationCharges(int invoiceId, double amount) {
        billingService.addConsultationCharges(invoiceId, amount);
    }

    public double getTotalRevenue() {
        return billingService.getTotalRevenue();
    }

    public double getTotalOutstanding() {
        return billingService.getTotalOutstandingAmount();
    }

    public List<Billing> getPendingInvoices() {
        return billingService.getPendingInvoices();
    }

    // ==================== Dashboard Analytics ====================

    public int getTotalPatients() {
        return patientService.getActivePatientCount();
    }

    public int getTotalDoctors() {
        return doctors.size();
    }

    public Map<String, Integer> getSystemStatistics() {
        Map<String, Integer> stats = new HashMap<>();
        stats.put("Total Patients", getTotalPatients());
        stats.put("Total Doctors", getTotalDoctors());
        stats.put("Total Appointments", getTotalAppointments());
        stats.put("Completed Appointments", getCompletedAppointments());
        stats.put("ICU Beds Available", getAvailableBedCount("ICU"));
        stats.put("General Beds Available", getAvailableBedCount("General"));
        stats.put("Emergency Beds Available", getAvailableBedCount("Emergency"));
        stats.put("Total Users", users.size());
        return stats;
    }

    public void displaySystemStatus() {
        System.out.println("\n========== APOLLO HOSPITAL - SYSTEM STATUS ==========");
        System.out.println("Total Active Patients: " + getTotalPatients());
        System.out.println("Total Registered Doctors: " + getTotalDoctors());
        System.out.println("Total Appointments: " + getTotalAppointments());
        System.out.println("Available ICU Beds: " + getAvailableBedCount("ICU"));
        System.out.println("Available General Beds: " + getAvailableBedCount("General"));
        System.out.println("Available Emergency Beds: " + getAvailableBedCount("Emergency"));
        System.out.println("Total Revenue: ₹" + getTotalRevenue());
        System.out.println("Outstanding Amount: ₹" + getTotalOutstanding());
        if (isICUFull()) {
            System.out.println("⚠️  ALERT: ICU BEDS ARE FULL!");
        }
        if (isEmergencyFull()) {
            System.out.println("⚠️  ALERT: EMERGENCY BEDS ARE FULL!");
        }
        System.out.println("===================================================\n");
    }
}

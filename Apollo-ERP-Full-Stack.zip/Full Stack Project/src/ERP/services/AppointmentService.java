package ERP.services;

import ERP.models.*;
import java.util.*;

/**
 * AppointmentService - Handles appointment scheduling and management
 */
public class AppointmentService {
    private List<Appointment> appointments;
    private int appointmentIdCounter;

    public AppointmentService() {
        this.appointments = new ArrayList<>();
        this.appointmentIdCounter = 5001;
    }

    /**
     * Book a new appointment
     */
    public Appointment bookAppointment(int patientId, int doctorId, String appointmentDate, 
                                       String appointmentTime, String department) {
        Appointment appointment = new Appointment(appointmentIdCounter++, patientId, doctorId, 
                                                  appointmentDate, appointmentTime, department);
        appointment.setCreatedDate(java.time.LocalDate.now().toString());
        appointments.add(appointment);
        return appointment;
    }

    /**
     * Get appointment by ID
     */
    public Appointment getAppointmentById(int appointmentId) {
        for (Appointment appointment : appointments) {
            if (appointment.getAppointmentId() == appointmentId) {
                return appointment;
            }
        }
        return null;
    }

    /**
     * Get appointments by patient ID
     */
    public List<Appointment> getAppointmentsByPatientId(int patientId) {
        List<Appointment> result = new ArrayList<>();
        for (Appointment appointment : appointments) {
            if (appointment.getPatientId() == patientId) {
                result.add(appointment);
            }
        }
        return result;
    }

    /**
     * Get appointments by doctor ID
     */
    public List<Appointment> getAppointmentsByDoctorId(int doctorId) {
        List<Appointment> result = new ArrayList<>();
        for (Appointment appointment : appointments) {
            if (appointment.getDoctorId() == doctorId) {
                result.add(appointment);
            }
        }
        return result;
    }

    /**
     * Get all appointments
     */
    public List<Appointment> getAllAppointments() {
        return new ArrayList<>(appointments);
    }

    /**
     * Reschedule appointment
     */
    public boolean rescheduleAppointment(int appointmentId, String newDate, String newTime) {
        Appointment appointment = getAppointmentById(appointmentId);
        if (appointment != null) {
            appointment.reschedule(newDate, newTime);
            return true;
        }
        return false;
    }

    /**
     * Cancel appointment
     */
    public boolean cancelAppointment(int appointmentId) {
        Appointment appointment = getAppointmentById(appointmentId);
        if (appointment != null) {
            appointment.cancel();
            return true;
        }
        return false;
    }

    /**
     * Mark appointment as completed
     */
    public boolean completeAppointment(int appointmentId) {
        Appointment appointment = getAppointmentById(appointmentId);
        if (appointment != null) {
            appointment.markCompleted();
            return true;
        }
        return false;
    }

    /**
     * Get upcoming appointments for a doctor
     */
    public List<Appointment> getUpcomingAppointmentsForDoctor(int doctorId, String currentDate) {
        List<Appointment> upcoming = new ArrayList<>();
        for (Appointment appointment : appointments) {
            if (appointment.getDoctorId() == doctorId && 
                "Scheduled".equalsIgnoreCase(appointment.getStatus()) &&
                appointment.getAppointmentDate().compareTo(currentDate) >= 0) {
                upcoming.add(appointment);
            }
        }
        return upcoming;
    }

    /**
     * Get appointments on a specific date
     */
    public List<Appointment> getAppointmentsByDate(String date) {
        List<Appointment> result = new ArrayList<>();
        for (Appointment appointment : appointments) {
            if (appointment.getAppointmentDate().equals(date)) {
                result.add(appointment);
            }
        }
        return result;
    }

    /**
     * Get appointments by department
     */
    public List<Appointment> getAppointmentsByDepartment(String department) {
        List<Appointment> result = new ArrayList<>();
        for (Appointment appointment : appointments) {
            if (department.equalsIgnoreCase(appointment.getDepartment())) {
                result.add(appointment);
            }
        }
        return result;
    }

    /**
     * Send reminder notification
     */
    public void sendAppointmentReminder(int appointmentId) {
        Appointment appointment = getAppointmentById(appointmentId);
        if (appointment != null) {
            appointment.setReminderSent("Email/SMS sent");
            System.out.println("Reminder sent for appointment: " + appointmentId);
        }
    }

    /**
     * Check appointment availability for doctor
     */
    public boolean isDoctorAvailableOnDateTime(int doctorId, String date, String time) {
        for (Appointment appointment : appointments) {
            if (appointment.getDoctorId() == doctorId &&
                appointment.getAppointmentDate().equals(date) &&
                appointment.getAppointmentTime().equals(time) &&
                "Scheduled".equalsIgnoreCase(appointment.getStatus())) {
                return false;
            }
        }
        return true;
    }

    /**
     * Get total appointments count
     */
    public int getTotalAppointmentCount() {
        return appointments.size();
    }

    /**
     * Get completed appointments count
     */
    public int getCompletedAppointmentCount() {
        int count = 0;
        for (Appointment appointment : appointments) {
            if ("Completed".equalsIgnoreCase(appointment.getStatus())) {
                count++;
            }
        }
        return count;
    }
}

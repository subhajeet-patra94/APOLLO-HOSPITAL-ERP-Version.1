package ERP.services;

import ERP.models.*;
import java.util.*;

/**
 * PatientService - Handles patient-related business logic
 */
public class PatientService {
    private List<Patient> patients;
    private int patientIdCounter;

    public PatientService() {
        this.patients = new ArrayList<>();
        this.patientIdCounter = 1001;
    }

    /**
     * Register a new patient
     */
    public Patient registerPatient(String firstName, String lastName, String email, 
                                   String phone, String dateOfBirth, String gender, 
                                   String address, String bloodGroup, String emergencyContact) {
        Patient patient = new Patient(patientIdCounter++, firstName, lastName, email, 
                                      phone, dateOfBirth, gender, address, bloodGroup, emergencyContact);
        patient.setRegistrationDate(java.time.LocalDate.now().toString());
        patients.add(patient);
        return patient;
    }

    /**
     * Get patient by ID
     */
    public Patient getPatientById(int patientId) {
        for (Patient patient : patients) {
            if (patient.getPatientId() == patientId) {
                return patient;
            }
        }
        return null;
    }

    /**
     * Search patients by name
     */
    public List<Patient> searchPatientsByName(String name) {
        List<Patient> result = new ArrayList<>();
        for (Patient patient : patients) {
            if (patient.getFirstName().toLowerCase().contains(name.toLowerCase()) ||
                patient.getLastName().toLowerCase().contains(name.toLowerCase())) {
                result.add(patient);
            }
        }
        return result;
    }

    /**
     * Get all patients
     */
    public List<Patient> getAllPatients() {
        return new ArrayList<>(patients);
    }

    /**
     * Update patient information
     */
    public boolean updatePatient(Patient updatedPatient) {
        for (int i = 0; i < patients.size(); i++) {
            if (patients.get(i).getPatientId() == updatedPatient.getPatientId()) {
                patients.set(i, updatedPatient);
                return true;
            }
        }
        return false;
    }

    /**
     * Discharge a patient
     */
    public boolean dischargePatient(int patientId) {
        Patient patient = getPatientById(patientId);
        if (patient != null) {
            patient.setStatus("Discharged");
            return true;
        }
        return false;
    }

    /**
     * Get count of active patients
     */
    public int getActivePatientCount() {
        int count = 0;
        for (Patient patient : patients) {
            if ("Active".equalsIgnoreCase(patient.getStatus())) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get medical history for a patient
     */
    public String getPatientMedicalHistory(int patientId) {
        Patient patient = getPatientById(patientId);
        if (patient != null) {
            return patient.getMedicalHistory();
        }
        return null;
    }

    /**
     * Update medical history
     */
    public boolean updateMedicalHistory(int patientId, String medicalHistory) {
        Patient patient = getPatientById(patientId);
        if (patient != null) {
            patient.setMedicalHistory(medicalHistory);
            return true;
        }
        return false;
    }

    /**
     * Delete a patient (set status to Inactive)
     */
    public boolean deletePatient(int patientId) {
        Patient patient = getPatientById(patientId);
        if (patient != null) {
            patient.setStatus("Inactive");
            return true;
        }
        return false;
    }
}

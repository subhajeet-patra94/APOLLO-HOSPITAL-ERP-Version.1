package ERP.services;

import ERP.models.*;
import java.util.*;

/**
 * BedService - Handles bed and ward management
 */
public class BedService {
    private List<Bed> beds;
    private int bedIdCounter;

    public BedService() {
        this.beds = new ArrayList<>();
        this.bedIdCounter = 1;
    }

    /**
     * Add a new bed
     */
    public Bed addBed(String wardName, String bedType, String bedNumber, String floor, double dailyRate) {
        Bed bed = new Bed(bedIdCounter++, wardName, bedType, bedNumber, floor, dailyRate);
        beds.add(bed);
        return bed;
    }

    /**
     * Get bed by ID
     */
    public Bed getBedById(int bedId) {
        for (Bed bed : beds) {
            if (bed.getBedId() == bedId) {
                return bed;
            }
        }
        return null;
    }

    /**
     * Get all beds
     */
    public List<Bed> getAllBeds() {
        return new ArrayList<>(beds);
    }

    /**
     * Get available beds by ward type
     */
    public List<Bed> getAvailableBedsByType(String bedType) {
        List<Bed> availableBeds = new ArrayList<>();
        for (Bed bed : beds) {
            if (bedType.equalsIgnoreCase(bed.getBedType()) && bed.isAvailable()) {
                availableBeds.add(bed);
            }
        }
        return availableBeds;
    }

    /**
     * Get available beds count by ward type
     */
    public int getAvailableBedCountByType(String bedType) {
        return getAvailableBedsByType(bedType).size();
    }

    /**
     * Occupy a bed
     */
    public boolean occupyBed(int bedId, int patientId, String admissionDate, String expectedDischargeDate) {
        Bed bed = getBedById(bedId);
        if (bed != null && bed.isAvailable()) {
            bed.occupyBed(patientId, admissionDate, expectedDischargeDate);
            return true;
        }
        return false;
    }

    /**
     * Discharge a patient from bed
     */
    public boolean dischargeBedByPatient(int patientId) {
        for (Bed bed : beds) {
            if (bed.getPatientId() == patientId) {
                bed.dischargeBed();
                return true;
            }
        }
        return false;
    }

    /**
     * Get bed occupancy by ward
     */
    public Map<String, Integer> getOccupancyByWard() {
        Map<String, Integer> occupancy = new HashMap<>();
        for (Bed bed : beds) {
            String ward = bed.getWardName();
            if (occupancy.containsKey(ward)) {
                if (!bed.isAvailable()) {
                    occupancy.put(ward, occupancy.get(ward) + 1);
                }
            } else {
                occupancy.put(ward, bed.isAvailable() ? 0 : 1);
            }
        }
        return occupancy;
    }

    /**
     * Get bed occupancy percentage by ward type
     */
    public double getOccupancyPercentageByType(String bedType) {
        int total = 0;
        int occupied = 0;
        for (Bed bed : beds) {
            if (bedType.equalsIgnoreCase(bed.getBedType())) {
                total++;
                if (!bed.isAvailable()) {
                    occupied++;
                }
            }
        }
        return total > 0 ? (occupied / (double) total) * 100 : 0;
    }

    /**
     * Get total bed count by type
     */
    public int getTotalBedCountByType(String bedType) {
        int count = 0;
        for (Bed bed : beds) {
            if (bedType.equalsIgnoreCase(bed.getBedType())) {
                count++;
            }
        }
        return count;
    }

    /**
     * Mark bed for maintenance
     */
    public boolean markBedForMaintenance(int bedId) {
        Bed bed = getBedById(bedId);
        if (bed != null && bed.isAvailable()) {
            bed.setStatus("Maintenance");
            return true;
        }
        return false;
    }

    /**
     * Release bed from maintenance
     */
    public boolean releaseBedFromMaintenance(int bedId) {
        Bed bed = getBedById(bedId);
        if (bed != null) {
            bed.setStatus("Available");
            return true;
        }
        return false;
    }

    /**
     * Get emergency alert - ICU beds full
     */
    public boolean isICUFull() {
        return getAvailableBedCountByType("ICU") == 0;
    }

    /**
     * Get emergency alert - Emergency beds full
     */
    public boolean isEmergencyBedsFull() {
        return getAvailableBedCountByType("Emergency") == 0;
    }
}

package ERP.services;

import ERP.models.*;
import java.util.*;

/**
 * BillingService - Handles billing and invoice management
 */
public class BillingService {
    private List<Billing> billings;
    private int invoiceIdCounter;

    public BillingService() {
        this.billings = new ArrayList<>();
        this.invoiceIdCounter = 2001;
    }

    /**
     * Create a new invoice
     */
    public Billing createInvoice(int patientId, int bedId, String admissionDate, String dischargeDate) {
        Billing billing = new Billing(invoiceIdCounter++, patientId, bedId, admissionDate, dischargeDate);
        billings.add(billing);
        return billing;
    }

    /**
     * Get invoice by ID
     */
    public Billing getInvoiceById(int invoiceId) {
        for (Billing billing : billings) {
            if (billing.getInvoiceId() == invoiceId) {
                return billing;
            }
        }
        return null;
    }

    /**
     * Get invoices by patient ID
     */
    public List<Billing> getInvoicesByPatientId(int patientId) {
        List<Billing> result = new ArrayList<>();
        for (Billing billing : billings) {
            if (billing.getPatientId() == patientId) {
                result.add(billing);
            }
        }
        return result;
    }

    /**
     * Get all invoices
     */
    public List<Billing> getAllInvoices() {
        return new ArrayList<>(billings);
    }

    /**
     * Calculate and add bed charges
     */
    public void addBedCharges(int invoiceId, int numberOfDays, double dailyRate) {
        Billing billing = getInvoiceById(invoiceId);
        if (billing != null) {
            double bedCharges = numberOfDays * dailyRate;
            billing.setBedCharges(bedCharges);
        }
    }

    /**
     * Add consultation charges
     */
    public void addConsultationCharges(int invoiceId, double amount) {
        Billing billing = getInvoiceById(invoiceId);
        if (billing != null) {
            billing.setConsultationCharges(billing.getConsultationCharges() + amount);
        }
    }

    /**
     * Add medicine charges
     */
    public void addMedicineCharges(int invoiceId, double amount) {
        Billing billing = getInvoiceById(invoiceId);
        if (billing != null) {
            billing.setMedicineCharges(billing.getMedicineCharges() + amount);
        }
    }

    /**
     * Add lab charges
     */
    public void addLabCharges(int invoiceId, double amount) {
        Billing billing = getInvoiceById(invoiceId);
        if (billing != null) {
            billing.setLabCharges(billing.getLabCharges() + amount);
        }
    }

    /**
     * Add other charges
     */
    public void addOtherCharges(int invoiceId, double amount) {
        Billing billing = getInvoiceById(invoiceId);
        if (billing != null) {
            billing.setOtherCharges(billing.getOtherCharges() + amount);
        }
    }

    /**
     * Calculate total amount
     */
    public double calculateTotalAmount(int invoiceId) {
        Billing billing = getInvoiceById(invoiceId);
        if (billing != null) {
            billing.calculateTotalAmount();
            return billing.getTotalAmount();
        }
        return 0.0;
    }

    /**
     * Record payment
     */
    public boolean recordPayment(int invoiceId, double amount, String paymentMethod) {
        Billing billing = getInvoiceById(invoiceId);
        if (billing != null) {
            billing.setAmountPaid(billing.getAmountPaid() + amount);
            billing.setPaymentMethod(paymentMethod);
            return true;
        }
        return false;
    }

    /**
     * Get pending invoices
     */
    public List<Billing> getPendingInvoices() {
        List<Billing> pending = new ArrayList<>();
        for (Billing billing : billings) {
            if ("Pending".equalsIgnoreCase(billing.getPaymentStatus())) {
                pending.add(billing);
            }
        }
        return pending;
    }

    /**
     * Get partial payment invoices
     */
    public List<Billing> getPartialPaymentInvoices() {
        List<Billing> partial = new ArrayList<>();
        for (Billing billing : billings) {
            if ("Partial".equalsIgnoreCase(billing.getPaymentStatus())) {
                partial.add(billing);
            }
        }
        return partial;
    }

    /**
     * Get paid invoices
     */
    public List<Billing> getPaidInvoices() {
        List<Billing> paid = new ArrayList<>();
        for (Billing billing : billings) {
            if ("Paid".equalsIgnoreCase(billing.getPaymentStatus())) {
                paid.add(billing);
            }
        }
        return paid;
    }

    /**
     * Generate revenue report
     */
    public double getTotalRevenue() {
        double total = 0;
        for (Billing billing : billings) {
            total += billing.getAmountPaid();
        }
        return total;
    }

    /**
     * Get revenue by month (simulated)
     */
    public double getRevenueByMonth(String month) {
        double revenue = 0;
        for (Billing billing : billings) {
            if (billing.getInvoiceDate().startsWith(month)) {
                revenue += billing.getAmountPaid();
            }
        }
        return revenue;
    }

    /**
     * Get total outstanding amount
     */
    public double getTotalOutstandingAmount() {
        double outstanding = 0;
        for (Billing billing : billings) {
            outstanding += billing.getPendingAmount();
        }
        return outstanding;
    }
}

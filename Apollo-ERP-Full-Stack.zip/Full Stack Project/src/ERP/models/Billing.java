package ERP.models;

/**
 * Billing Model - Represents billing and invoice information
 */
public class Billing {
    private int invoiceId;
    private int patientId;
    private int bedId;
    private String invoiceDate;
    private String admissionDate;
    private String dischargeDate;
    private double bedCharges;
    private double consultationCharges;
    private double medicineCharges;
    private double labCharges;
    private double otherCharges;
    private double totalAmount;
    private double amountPaid;
    private double pendingAmount;
    private String paymentStatus; // Pending, Partial, Paid
    private String paymentMethod; // Cash, Card, Insurance, Online
    private String insuranceProvider;
    private String insurancePolicyNumber;
    private String insuredAmount;
    private String notes;

    // Constructor
    public Billing(int invoiceId, int patientId, int bedId, String admissionDate, String dischargeDate) {
        this.invoiceId = invoiceId;
        this.patientId = patientId;
        this.bedId = bedId;
        this.admissionDate = admissionDate;
        this.dischargeDate = dischargeDate;
        this.invoiceDate = java.time.LocalDate.now().toString();
        this.paymentStatus = "Pending";
        this.amountPaid = 0.0;
    }

    // Getters and Setters
    public int getInvoiceId() { return invoiceId; }
    public void setInvoiceId(int invoiceId) { this.invoiceId = invoiceId; }

    public int getPatientId() { return patientId; }
    public void setPatientId(int patientId) { this.patientId = patientId; }

    public int getBedId() { return bedId; }
    public void setBedId(int bedId) { this.bedId = bedId; }

    public String getInvoiceDate() { return invoiceDate; }
    public void setInvoiceDate(String invoiceDate) { this.invoiceDate = invoiceDate; }

    public String getAdmissionDate() { return admissionDate; }
    public void setAdmissionDate(String admissionDate) { this.admissionDate = admissionDate; }

    public String getDischargeDate() { return dischargeDate; }
    public void setDischargeDate(String dischargeDate) { this.dischargeDate = dischargeDate; }

    public double getBedCharges() { return bedCharges; }
    public void setBedCharges(double bedCharges) { this.bedCharges = bedCharges; }

    public double getConsultationCharges() { return consultationCharges; }
    public void setConsultationCharges(double consultationCharges) { 
        this.consultationCharges = consultationCharges; 
    }

    public double getMedicineCharges() { return medicineCharges; }
    public void setMedicineCharges(double medicineCharges) { this.medicineCharges = medicineCharges; }

    public double getLabCharges() { return labCharges; }
    public void setLabCharges(double labCharges) { this.labCharges = labCharges; }

    public double getOtherCharges() { return otherCharges; }
    public void setOtherCharges(double otherCharges) { this.otherCharges = otherCharges; }

    public double getTotalAmount() { return totalAmount; }
    public void calculateTotalAmount() {
        this.totalAmount = bedCharges + consultationCharges + medicineCharges + labCharges + otherCharges;
    }

    public double getAmountPaid() { return amountPaid; }
    public void setAmountPaid(double amountPaid) { 
        this.amountPaid = amountPaid;
        this.pendingAmount = this.totalAmount - amountPaid;
        updatePaymentStatus();
    }

    public double getPendingAmount() { return pendingAmount; }
    public void setPendingAmount(double pendingAmount) { this.pendingAmount = pendingAmount; }

    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }

    public String getInsuranceProvider() { return insuranceProvider; }
    public void setInsuranceProvider(String insuranceProvider) { this.insuranceProvider = insuranceProvider; }

    public String getInsurancePolicyNumber() { return insurancePolicyNumber; }
    public void setInsurancePolicyNumber(String insurancePolicyNumber) { 
        this.insurancePolicyNumber = insurancePolicyNumber; 
    }

    public String getInsuredAmount() { return insuredAmount; }
    public void setInsuredAmount(String insuredAmount) { this.insuredAmount = insuredAmount; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    private void updatePaymentStatus() {
        if (pendingAmount <= 0) {
            this.paymentStatus = "Paid";
        } else if (amountPaid > 0) {
            this.paymentStatus = "Partial";
        } else {
            this.paymentStatus = "Pending";
        }
    }

    @Override
    public String toString() {
        return "Billing{" +
                "invoiceId=" + invoiceId +
                ", patientId=" + patientId +
                ", totalAmount=" + totalAmount +
                ", amountPaid=" + amountPaid +
                ", pendingAmount=" + pendingAmount +
                ", paymentStatus='" + paymentStatus + '\'' +
                '}';
    }
}

package ERP.models;

/**
 * Bed Model - Represents a bed in the hospital system
 */
public class Bed {
    private int bedId;
    private String wardName;
    private String bedType; // ICU, General, Emergency, Maternity
    private String bedNumber;
    private String status; // Available, Occupied, Maintenance
    private int patientId; // If occupied
    private String admissionDate;
    private String expectedDischargeDate;
    private double dailyRate;
    private String equipment; // Ventilator, Monitor, etc.
    private String floor;

    // Constructor
    public Bed(int bedId, String wardName, String bedType, String bedNumber, 
               String floor, double dailyRate) {
        this.bedId = bedId;
        this.wardName = wardName;
        this.bedType = bedType;
        this.bedNumber = bedNumber;
        this.floor = floor;
        this.dailyRate = dailyRate;
        this.status = "Available";
        this.patientId = -1;
    }

    // Getters and Setters
    public int getBedId() { return bedId; }
    public void setBedId(int bedId) { this.bedId = bedId; }

    public String getWardName() { return wardName; }
    public void setWardName(String wardName) { this.wardName = wardName; }

    public String getBedType() { return bedType; }
    public void setBedType(String bedType) { this.bedType = bedType; }

    public String getBedNumber() { return bedNumber; }
    public void setBedNumber(String bedNumber) { this.bedNumber = bedNumber; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public int getPatientId() { return patientId; }
    public void setPatientId(int patientId) { this.patientId = patientId; }

    public String getAdmissionDate() { return admissionDate; }
    public void setAdmissionDate(String admissionDate) { this.admissionDate = admissionDate; }

    public String getExpectedDischargeDate() { return expectedDischargeDate; }
    public void setExpectedDischargeDate(String expectedDischargeDate) { 
        this.expectedDischargeDate = expectedDischargeDate; 
    }

    public double getDailyRate() { return dailyRate; }
    public void setDailyRate(double dailyRate) { this.dailyRate = dailyRate; }

    public String getEquipment() { return equipment; }
    public void setEquipment(String equipment) { this.equipment = equipment; }

    public String getFloor() { return floor; }
    public void setFloor(String floor) { this.floor = floor; }

    public boolean isAvailable() {
        return "Available".equalsIgnoreCase(this.status);
    }

    public void occupyBed(int patientId, String admissionDate, String expectedDischargeDate) {
        this.patientId = patientId;
        this.status = "Occupied";
        this.admissionDate = admissionDate;
        this.expectedDischargeDate = expectedDischargeDate;
    }

    public void dischargeBed() {
        this.patientId = -1;
        this.status = "Available";
        this.admissionDate = null;
        this.expectedDischargeDate = null;
    }

    @Override
    public String toString() {
        return "Bed{" +
                "bedId=" + bedId +
                ", wardName='" + wardName + '\'' +
                ", bedType='" + bedType + '\'' +
                ", bedNumber='" + bedNumber + '\'' +
                ", status='" + status + '\'' +
                ", floor='" + floor + '\'' +
                '}';
    }
}

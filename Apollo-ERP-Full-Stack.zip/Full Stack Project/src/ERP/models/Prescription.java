package ERP.models;

/**
 * Prescription Model - Represents prescriptions given to patients
 */
public class Prescription {
    private int prescriptionId;
    private int patientId;
    private int doctorId;
    private String medicineeName;
    private String dosage;
    private String frequency; // Once daily, Twice daily, etc.
    private String duration;
    private String prescriptionDate;
    private String notes;
    private String status; // Active, Completed, Cancelled
    private String expiryDate;
    private boolean refillAllowed;
    private int refillCount;

    // Constructor
    public Prescription(int prescriptionId, int patientId, int doctorId, 
                       String medicineeName, String dosage, String frequency, String duration) {
        this.prescriptionId = prescriptionId;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.medicineeName = medicineeName;
        this.dosage = dosage;
        this.frequency = frequency;
        this.duration = duration;
        this.prescriptionDate = java.time.LocalDate.now().toString();
        this.status = "Active";
        this.refillAllowed = true;
        this.refillCount = 0;
    }

    // Getters and Setters
    public int getPrescriptionId() { return prescriptionId; }
    public void setPrescriptionId(int prescriptionId) { this.prescriptionId = prescriptionId; }

    public int getPatientId() { return patientId; }
    public void setPatientId(int patientId) { this.patientId = patientId; }

    public int getDoctorId() { return doctorId; }
    public void setDoctorId(int doctorId) { this.doctorId = doctorId; }

    public String getMedicineeName() { return medicineeName; }
    public void setMedicineeName(String medicineeName) { this.medicineeName = medicineeName; }

    public String getDosage() { return dosage; }
    public void setDosage(String dosage) { this.dosage = dosage; }

    public String getFrequency() { return frequency; }
    public void setFrequency(String frequency) { this.frequency = frequency; }

    public String getDuration() { return duration; }
    public void setDuration(String duration) { this.duration = duration; }

    public String getPrescriptionDate() { return prescriptionDate; }
    public void setPrescriptionDate(String prescriptionDate) { this.prescriptionDate = prescriptionDate; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getExpiryDate() { return expiryDate; }
    public void setExpiryDate(String expiryDate) { this.expiryDate = expiryDate; }

    public boolean isRefillAllowed() { return refillAllowed; }
    public void setRefillAllowed(boolean refillAllowed) { this.refillAllowed = refillAllowed; }

    public int getRefillCount() { return refillCount; }
    public void setRefillCount(int refillCount) { this.refillCount = refillCount; }

    public void refill() {
        if (refillAllowed) {
            this.refillCount++;
        }
    }

    public void markCompleted() {
        this.status = "Completed";
    }

    @Override
    public String toString() {
        return "Prescription{" +
                "prescriptionId=" + prescriptionId +
                ", patientId=" + patientId +
                ", medicineeName='" + medicineeName + '\'' +
                ", dosage='" + dosage + '\'' +
                ", frequency='" + frequency + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}

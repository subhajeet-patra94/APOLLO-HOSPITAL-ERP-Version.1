# 🚀 HOW TO RUN APOLLO HOSPITAL ERP SYSTEM

## **3 Different Methods to Run the Project**

---

## **METHOD 1: RUN FROM ECLIPSE IDE (EASIEST) ✅**

### Step 1: Open Eclipse
- Click on Eclipse icon on your desktop or taskbar

### Step 2: Open the Project
1. Go to **File → Open Projects from File System**
2. Navigate to: `C:\Users\subha\eclipse-workspace\Full Stack Project`
3. Click **Finish**

### Step 3: Navigate to ApolloHospital.java
```
Full Stack Project
  └─ src
      └─ ERP
          └─ ApolloHospital.java  ← Click here
```

### Step 4: Run the Program
1. **Right-click** on `ApolloHospital.java`
2. Select **Run As → Java Application**
3. View output in the **Console** tab at bottom

**That's it! You'll see the demo output in the Console.** ✅

---

## **METHOD 2: RUN FROM COMMAND PROMPT (WINDOWS) ⚡**

### Step 1: Open Command Prompt
- Press `Windows Key + R`
- Type: `cmd`
- Press `Enter`

### Step 2: Navigate to Project Folder
```bash
cd C:\Users\subha\eclipse-workspace\Full Stack Project
```

### Step 3: Run the System
```bash
java -cp bin ERP.ApolloHospital
```

### Step 4: See the Output
The demo will run automatically and show all the features!

**Example Command:**
```
C:\Users\subha\eclipse-workspace\Full Stack Project> java -cp bin ERP.ApolloHospital
```

---

## **METHOD 3: RUN FROM POWERSHELL (WINDOWS 10+) ⚡**

### Step 1: Open PowerShell
- Press `Windows Key`
- Type: `PowerShell`
- Click **Windows PowerShell**

### Step 2: Navigate to Project
```powershell
cd "C:\Users\subha\eclipse-workspace\Full Stack Project"
```

### Step 3: Run the System
```powershell
java -cp bin ERP.ApolloHospital
```

---

## **QUICK REFERENCE - Copy & Paste Commands**

### For Command Prompt (cmd.exe):
```
cd C:\Users\subha\eclipse-workspace\Full Stack Project && java -cp bin ERP.ApolloHospital
```

### For PowerShell:
```powershell
cd "C:\Users\subha\eclipse-workspace\Full Stack Project"; java -cp bin ERP.ApolloHospital
```

---

## **TROUBLESHOOTING**

### ❌ Error: "java: command not found"
**Solution:** Java is not in PATH
1. Install Java from https://www.oracle.com/java/technologies/javase-downloads.html
2. Add Java to PATH (restart computer after install)

### ❌ Error: "The system cannot find the path specified"
**Solution:** Wrong directory path
1. Check the path is correct: `C:\Users\subha\eclipse-workspace\Full Stack Project`
2. Make sure you're in the right folder with `dir` command

### ❌ Error: "file not found" or "ApolloHospital.class"
**Solution:** Project not compiled
1. Open Eclipse
2. Right-click on project → **Build Project** or press `Ctrl+B`
3. Wait for compilation to complete
4. Then run again

### ❌ Program starts but shows no output
**Solution:** Check Console tab
1. In Eclipse, look for **Console** tab at bottom
2. Click it to see the output
3. If still nothing, rebuild the project

---

## **WHAT YOU'LL SEE WHEN IT RUNS**

```
╔════════════════════════════════════════════════════════╗
║    APOLLO HOSPITAL MANAGEMENT ERP SYSTEM v1.0         ║
║    Full Stack Hospital Management Solution           ║
╚════════════════════════════════════════════════════════╝

Welcome to Apollo Hospital Management System
Integrated Patient, Bed, Doctor & Billing Modules
Tech Stack: Java Backend | React Frontend | PostgreSQL

========== DEMO: Registering New Patient ==========
✓ Patient Registered: Patient{patientId=1001, ...}

========== DEMO: Booking Appointment ==========
✓ Appointment Booked: Appointment{appointmentId=5001, ...}
  Doctor: Rajesh Kumar
  Consultation Fee: ₹500.0

========== DEMO: Admitting Patient to Bed ==========
✓ Patient Admitted to Bed: ICU-101
  Ward: ICU
  Daily Rate: ₹5000.0

========== DEMO: Creating Billing Invoice ==========
✓ Invoice Created: #2001
✓ Charges Added - Bed (5 days @ ₹5000): ₹25000
✓ Charges Added - Consultation: ₹500
  Total Invoice Amount: ₹25500

========== DEMO: System Statistics ==========
[Hospital Statistics]

========== DEMO: Available Doctors ==========
[List of 3 Doctors]

========== DEMO: Bed Occupancy Report ==========
[Bed Status]

========== DEMO: Financial Summary ==========
[Financial Report]

╔════════════════════════════════════════════════════════╗
║  DEMO COMPLETED SUCCESSFULLY                          ║
║  System is ready for full-scale deployment            ║
╚════════════════════════════════════════════════════════╝
```

---

## **PREFERRED METHOD - RECOMMENDATION**

### 🏆 **BEST FOR BEGINNERS: METHOD 1 (Eclipse IDE)**
- ✅ No command line needed
- ✅ Visual interface
- ✅ Easier debugging
- ✅ Can see output in Console

### ⚡ **BEST FOR QUICK RUN: METHOD 2 (Command Prompt)**
- ✅ Fastest method
- ✅ No IDE needed
- ✅ Simple one-line command
- ✅ Good for production

### 💻 **BEST FOR DEVELOPERS: METHOD 3 (PowerShell)**
- ✅ Modern terminal
- ✅ Better formatting
- ✅ Advanced features
- ✅ Professional setup

---

## **STEP-BY-STEP WITH SCREENSHOTS**

### **Using Eclipse IDE:**

```
1. Eclipse Home Screen
   └─ Click on "Open Projects from File System"
   
2. Select Project Folder
   └─ Navigate to: C:\Users\subha\eclipse-workspace\Full Stack Project
   └─ Click Finish
   
3. Project Opened in Eclipse
   └─ Full Stack Project
       └─ src
           └─ ERP
               └─ ApolloHospital.java
   
4. Right-click ApolloHospital.java
   └─ Select "Run As"
   └─ Click "Java Application"
   
5. See Output in Console
   └─ Bottom of screen shows demo output
```

---

## **AFTER RUNNING**

### What the Program Does:
1. ✅ Creates a new patient (Vikram Singh)
2. ✅ Books an appointment with a doctor
3. ✅ Admits the patient to a hospital bed
4. ✅ Creates a billing invoice
5. ✅ Shows system statistics
6. ✅ Displays bed occupancy report
7. ✅ Shows financial summary

### Program Duration:
- Takes **2-3 seconds** to run completely
- Data is stored **in memory only** (lost when program ends)
- No database or file storage needed

---

## **RUNNING MULTIPLE TIMES**

You can run the program as many times as you want:
- Each run starts fresh with new data
- No data carries over from previous runs
- Perfect for testing different scenarios

```bash
# Run it once
java -cp bin ERP.ApolloHospital

# After it finishes, run again
java -cp bin ERP.ApolloHospital

# Each run shows a new patient being registered
```

---

## **IF YOU MODIFY CODE**

### If you change any Java files:

#### In Eclipse:
1. Make your changes
2. Save the file (`Ctrl+S`)
3. Right-click project → **Build Project** (or `Ctrl+B`)
4. Then run again with `Run As → Java Application`

#### In Command Prompt:
1. Make your changes in any text editor
2. Recompile:
```bash
cd C:\Users\subha\eclipse-workspace\Full Stack Project\src
javac -d ..\bin ERP\*.java ERP\models\*.java ERP\services\*.java
```
3. Run again:
```bash
cd ..
java -cp bin ERP.ApolloHospital
```

---

## **FILE LOCATIONS**

```
C:\Users\subha\eclipse-workspace\Full Stack Project\
├─ src\                          ← Source code files
│  └─ ERP\
│     ├─ ApolloHospital.java     ← Entry point (Run this)
│     ├─ HospitalManagementSystem.java
│     ├─ models\                 ← Data models
│     │  ├─ Patient.java
│     │  ├─ Doctor.java
│     │  ├─ Bed.java
│     │  ├─ Appointment.java
│     │  ├─ Billing.java
│     │  ├─ Prescription.java
│     │  └─ User.java
│     └─ services\               ← Business logic
│        ├─ PatientService.java
│        ├─ BedService.java
│        ├─ AppointmentService.java
│        └─ BillingService.java
│
├─ bin\                          ← Compiled .class files
│  └─ ERP\
│     ├─ ApolloHospital.class    ← Compiled main class
│     └─ ...other.class files
│
├─ .classpath                    ← Eclipse configuration
├─ .project                      ← Eclipse project file
└─ README.md                     ← Documentation
```

---

## **SUMMARY TABLE**

| Method | Command | Time | Difficulty |
|--------|---------|------|------------|
| **Eclipse IDE** | Right-click → Run As | 5 sec | ⭐ Easy |
| **Command Prompt** | `java -cp bin ERP.ApolloHospital` | 10 sec | ⭐⭐ Medium |
| **PowerShell** | `java -cp bin ERP.ApolloHospital` | 10 sec | ⭐⭐⭐ Advanced |

---

## **QUICK START CHECKLIST**

- [ ] Open Eclipse
- [ ] Open "Full Stack Project"
- [ ] Navigate to src → ERP → ApolloHospital.java
- [ ] Right-click and select "Run As → Java Application"
- [ ] View output in Console tab
- [ ] See the demo running! 🎉

---

**Choose the method that works best for you and enjoy seeing the Apollo Hospital ERP System in action!** 🏥


# ⚡ GITHUB UPLOAD - QUICK START

---

## **🎯 YOUR DETAILS**

✅ **GitHub Username:** subhajeet-patra94
✅ **Email:** subhajeetp@outlook.com
✅ **Repository:** Apollo-Hospital-ERP

---

## **🚀 DO THIS NOW (5 Minutes)**

### **Step 1: Create GitHub Repository (1 minute)**

Go to: https://github.com/new

Fill in:
- **Name:** Apollo-Hospital-ERP
- **Description:** Apollo Hospital Management ERP System

Click: **Create repository**

---

### **Step 2: Upload Your Project (2-3 minutes)**

**Open File Explorer** (Windows Key + E)

**Navigate to:** `C:\Users\subha\eclipse-workspace\Full Stack Project`

**Double-click:** `GITHUB_UPLOAD_SECURE.bat`

**When prompted:** Enter your GitHub Personal Access Token

**Wait for completion!**

---

## **✨ RESULT**

Your project will be at:
```
https://github.com/subhajeet-patra94/Apollo-Hospital-ERP
```

---

## **🎊 DONE!**

Your Apollo Hospital ERP System is now on GitHub! 🚀

